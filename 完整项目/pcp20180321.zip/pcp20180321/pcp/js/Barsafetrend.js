function Map_safeTrend(id,prename,nowname,dataPre,dataNow){
    
    option = {
        
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            data:[prename,nowname],
            bottom:2,
            orient:'horizontal',

            
        },
        toolbox: {
            show : true,
            feature : {
                
                magicType : {show: true, type: ['line', 'bar']},
                
                
            }
        },
        calculable : true,
        xAxis : 
        {
            type : 'category',
            data : ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'],
            axisLine: {
            show: false
            },
            axisTick: {
                show: false,
                alignWithLabel: true
            },
            axisLabel: {
                textStyle: {
                    color: "#f00"
                }
            }
        }
        ,
        yAxis : [
        {
            type : 'value',
            axisLine: {
            show: false
            },
            axisTick: {
                show: false
            },
            axisLabel: {
                show: false
            },
            splitLine: {
                show: false
            }
        }
        ],
        grid:{
            x:20,
            y:20,
            right:20
        },
        series : [
        {
            name:prename,
            type:'bar',
            data:dataPre,
            barWidth:13,
            itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
                    offset: 0,
                    color: "rgb(0,147,203)" // 0% 处的颜色
                }, {
                    offset: 1,
                    color: "rgb(0,88,153)" // 100% 处的颜色
                }], false),
            },

        },
        {
            name:nowname,
            type:'bar',
            data:dataNow,
            barWidth:13,
            itemStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
                    offset: 0,
                    color: "rgb(137,210,0)" // 0% 处的颜色
                }, {
                    offset: 1,
                    color: "rgb(65,118,5)" // 100% 处的颜色
                }], false),

            }
        }
        ]
    };
    var chart =  echarts.init(document.getElementById(id));
    chart.setOption(option);
}
        
   
 
