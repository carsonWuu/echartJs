function Map(id,cityData,rawData){     
    
    function sortRule(a,b){
        return b.value-a.value;
    }
    cityData.sort(sortRule);
   
    var top10=[];
    var cityCount=0;
    if(cityData.length<=10){cityCount=cityData.length;}
    else cityCount=10;
    for(var i=0;i<cityCount;i++){
        top10.unshift(cityData[i]);
    }
     var name=top10.map(name=>name.name);

    var chart =  echarts.init(document.getElementById(id));

    var geoCoordMap = {'珠海市': [113.353986,21.924979]
	,'广州市':[113.351856,23.107921]
	,'湛江市':[110.264977,21.274898]
	,'茂名市':[110.919229,21.659751]
	,'阳江市':[111.825107,21.859222]
	,'云浮市':[112.044439,22.629801]
	,'肇庆市':[112.472529,23.051546]
	,'江门市':[112.894942,22.090431]
	,'中山市':[113.382391,22.321113]
	,'佛山市':[113.022717,22.828762]
	,'清远市':[113.051227,23.685022]
	,'韶关市':[113.591544,24.501322]
	,'河源市':[114.897802,23.746266]
	,'梅州市':[116.117582,24.099112]
	,'潮州市':[116.692301,23.661701]
	,'揭阳市':[116.255733,23.143778]
	,'汕头市':[116.708463,23.10102]
	,'汕尾市':[115.364238,22.774485]
	,'深圳市':[114.085947,22.347]
	,'东莞市':[113.746262,22.746237]
	,'惠州市':[114.412599,23.079404]
	};

	var option = {
//	     backgroundColor:'rgb(255, 255, 255)',
	legend: [],
	title:[{
	    text:'全省IDC安全态势',
	show:true,
	x:0,
	textStyle:{
	    color:'rgb(0, 81, 175)',
	        fontSize:15
	    }
	},{
	    text: "综合安全事件影响排名Top10",
	textStyle: {
	    color: "#000",
	fontWeight: "bold",
	    fontSize: 14
	},
	top: "55%",
	left: "69%"
	}],
	xAxis: [{
	    type: "value",
	    axisLine: {
	        show: false
	    },
	    axisTick: {
	        show: false
	    },
	    axisLabel: {
	        show: false
	    },
	    splitLine: {
	        show: false
	    }
	},],
	yAxis: [{
	    type: "category",
	    data: cityData,
	    axisLine: {
	        show: false
	    },
	    axisTick: {
	        show: false,
	        
	    },
	    axisLabel: {
	        textStyle:{
	            fontSize:100  
	        }
	    },
	    data:name,
	},],
	grid: [{
	    left: "70%",
	right: "50",
	bottom: "10",
	top:'60%',
	    containLabel: true
	},],
	
	tooltip:[{
	    // formatter:function(params){
	// console.log(params)
	// var content='',
	// content=params.name+params.value[0]+params.value[1]+params.value[2];
	// return content;
	// },
	        show:true,
	    }],
	   
	    // visualMap: {
	// show: false,
	// min: 0,
	// max: 3000,
	// inRange: {
	// color: ['#00ffff', '#006edd'],
	// color: ['#00467F', '#A5CC82']
	// },
	// calculable:true
	
	// },
	
	geo:{
	
	    show:true,
	    map:'广东',
	type:'map',
	x:'15%',
	label: {
	    normal: {
	        show: false
	    },
	    emphasis: {
	        show: true,
	    }
	},
	roam: false,
	itemStyle: {
	    normal: {
	        areaColor: ['rgb(0,90,157)'],
	borderColor: '#fff',
	borderWidth: '0.8',
	},
	emphasis: {
	    areaColor: '#2B91B7',
	        }
	    }
	},
	series: [{
	    name: "安全事件数量",
	type: "bar",
	data: top10,
	barWidth:7,
	barCategoryGap: "50%",
	label: {
	    normal: {
	        left:'right',
	show: true,
	position: "right",
	    formatter: function(params) {
	        return params.data.value;
	    },
	    textStyle: {
	color: "#000" // color of value
	        }
	    }
	},
	itemStyle: {
	    normal: {
	        color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
	            offset: 0,
	            color: "rgb(231,91,250)" // 0% 处的颜色
	}, {
	    offset: 1,
	    color: "rgb(80,50,180)" // 100% 处的颜色
	            }], false),
	            barBorderRadius: [30, 30,30, 30],
	        }
	    }
	},]
	
	    };// option
	chart.setOption(option);
	
	function renderEachCity() {  
	    var width=$('#'+id).width();
	var height=$('#'+id).height();
	
	// option.xAxis.push();
	// option.yAxis.push();
	// option.grid.push();
	// option.series.push();
	echarts.util.each(rawData, function(dataItem, idx) {
	
	    var geoCoord = geoCoordMap[dataItem.name];
	
	    var coord = chart.convertToPixel('geo', geoCoord);
	idx += '';
	var barHeight=dataItem.value*470/20000;
	option.xAxis.push({
	    id: idx,
	    gridId: idx,
	    type: 'category',
	    show: false
	});
	option.yAxis.push({
	    id: idx,
	    gridId: idx,
	    show: false
	});
	option.grid.push({
	    id: idx,
	    width: 10,
	    height: barHeight+30,
	    left: coord[0],
	    bottom:height-coord[1]+10,
	});
	
	
	option.series.push({
	    name:dataItem.name,
	    type: 'bar',
	xAxisId: idx,
	yAxisId: idx,
	road:true,
	itemStyle: {
	    normal: {
	        color:new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
	            offset: 0,
	            color: 'rgb(231,91,250)'
	}, {
	    offset: 1,
	    color: 'rgb(80,50,180)'
	    }], false),
	    borderColor:'rgba(255,255,255,0.8)',
	    barBorderRadius: [30, 30,30, 30],
	},
	emphasis:{
	    color:new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
	        offset: 1,
	        color: 'rgb(231,91,250)'
	}, {
	    offset: 0,
	    color: 'rgb(80,50,180)'
	                    }], false)
	                }
	            },
	            data: [dataItem.value]
	        });
	
	
	    });
	    chart.setOption(option);
	}
	
	renderEachCity();
	
	
	chart.on('click',function(params){
	    	clickcity(params.name);
    })

}
