var data = [
		{name:'陕西', value: 3, url: 111},
		{name:'广西', value: 3, url: 111},
		{name:'江西', value: 3, url: 111},
		{name:'重庆', value: 3, url: 111},
		{name:'天津', value: 3, url: 111},
		{name:'云南', value: 2, url: 111},
		{name:'山西', value: 2, url: 111},
		{name:'黑龙江', value: 2, url: 111},
		{name:'吉林', value: 2, url: 111},
		{name:'内蒙古', value: 2, url: 111},
		{name:'贵州', value: 2, url: 111},
		{name:'甘肃', value: 14, url:"http://baidu.com"},
		{name:'海南', value: 2, url: 111},
		{name:'宁夏', value: 2, url: 111},
		{name:'青海', value: 1, url: 111},
		{name:'西藏', value: 1, url: 111},
		{name:'香港', value: 1, url: 111},
		{name:'未知', value: 1, url: 111},
		{name:'台湾', value: 1, url: 111}
	];

	function on_click(e, ev) {

		var txt = $(e).html();
		//console.log(txt);
		var name=txt.split('(')[0];
		//console.log(event);
		for(var i=0;i<data.length;i++){
			if(data[i].name==name){
				console.log('click:'+name+':isFind!');
			}
		}
		
	}
	function on_mouseover(e,ev){
		//console.log($('#'+e.id).text())
		document.getElementById(e.id).style.textDecoration='underline'; 
		document.getElementById(e.id).style.fontSize='20px';
		document.getElementById(e.id).style.cursor='pointer';  
	}
	function on_mouseout(e,ev){
		//console.log($('#'+e.id).text());
		document.getElementById(e.id).style.textDecoration='none';
		document.getElementById(e.id).style.fontSize='10px'; 
		//document.getElementById(e.id).style.cursor='none';  
	}
	function cloud(id,data){
	var string_ = "";
	for (var i = 0; i < data.length; i++) {
		var string_f = data[i].name;
		var string_n = data[i].value;
		var temp=string_f+'('+string_n+')';
		string_ += "{text: '" + temp + "',html: {'class': 'span_list',onclick:'on_click(this,event)',onmouseover:'on_mouseover(this,event)',onmouseout:'on_mouseout(this,event)'}},";
	}

	

	$(function() {
		$('#'+id).jQCloud(word_list);
	});
	var string_list = string_;
	
	var word_list = eval("[" + string_list + "]");
	//console.log(word_list)
}
cloud('wxgz_content',data);