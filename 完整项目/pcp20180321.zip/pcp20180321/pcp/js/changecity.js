var city;
//下拉框选择改变事件
function show_sub(v){     
	city=v;
	//加载地级市
	loadcitymap(city);
}
function loadcitymap(city){
	var pathName=window.document.location.pathname;
	var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);
	if(city==0){
		window.location.href=projectName+"/pcp/jsp/provinceMainfrain.jsp";
	}
	if(city=='广州市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_gz.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_gz.jsp");
	}
	if(city=='深圳市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_sz.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_sz.jsp");
	}
	if(city=='珠海市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_zh.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_zh.jsp");
	}
	if(city=='东莞市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_dg.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_dg.jsp");
	}
	if(city=='惠州市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_hz.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_hz.jsp");
	}
	if(city=='中山市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_zs.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_zs.jsp");
	}
	if(city=='佛山市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_fs.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_fs.jsp");
	}
	if(city=='汕头市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_st.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_st.jsp");
	}
	if(city=='江门市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_jm.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_jm.jsp");
	}
	if(city=='茂名市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_mm.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_mm.jsp");
	}
	
	if(city=='肇庆市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_zq.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_zq.jsp");
	}
	if(city=='湛江市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_zj.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_zj.jsp");
	}
	if(city=='梅州市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_mz.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_mz.jsp");
	}
	if(city=='汕尾市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_sw.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_sw.jsp");
	}
	if(city=='河源市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_hy.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_hy.jsp");
	}
	if(city=='清远市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_qy.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_qy.jsp");
	}
	if(city=='韶关市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_sg.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_sg.jsp");
	}
	if(city=='揭阳市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_jy.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_jy.jsp");
	}
	if(city=='阳江市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_yj.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_yj.jsp");
	}
	if(city=='潮州市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_cz.jsp";
//		window.location.href=projectName+"/pcp/jsp/cityMainfrain_cz.jsp";
	}
	if(city=='云浮市'){
		window.location.href=projectName+"/pcp/jsp/cityMainfrain_yf.jsp";
//		$("#mainFrame").attr("src","cityMainfrain_yf.jsp");
	}
	
}

    
