var flag1=1;//未处理
var flag2=1;//已关停
var flag3=1;//已下发

var flag4=1;//未处理
var flag5=1;//已关停
var flag6=1;//已下发

var flag7=1;//未处理
var flag8=1;//已关停
var flag9=1;//已下发

var num = 0;
var rawData_city = [
    {name: '惠州idc3',value:81},
    {name: '惠州idc4',value:18},
    {name: '惠州idc6',value:16},
    {name: '惠州idc2',value: 58}
    
    ];
var geoCoordMap = {
	    '惠州idc1':[114.430822,23.075188],
	    '惠州idc2':[114.430822,23.075188],
	    '惠州idc3':[114.54523,23.045926],
	    '惠州idc4':[114.646415,23.101784],
	    '惠州idc5':[114.253173,22.98419],
	    '惠州idc6':[114.453819,22.954909]
	    };
var arr=[{name:'1号',value:30},{name:'2号',value:20},{name:'3号',value:10},{name:'4号',value:50}];//曲线数据
var pre=[100.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3];//前一年度数
var now=[2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8];//当前年度数据
var message_xxaq=[{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"已关停"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"已下发"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"}];//信息安全事件
var message_wlaq=[{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"}];//网络安全事件	
var message_wba=[{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"}];//未备案
var message_zgcl=[{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"45","beian":"78","process":"89"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"78","beian":"45","process":"56"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"784","beian":"45","process":"14"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"45","beian":"78","process":"94"}];//整改处理
var message_ywgtyhf=[{"idc_name":"惠州idc1","idc_room":"机房1","having":"14","sqhf":"25","ysl":"42","shz":"5","ysh":"7"},{"idc_name":"惠州idc1","idc_room":"机房1","having":"14","sqhf":"25","ysl":"42","shz":"5","ysh":"7"}];//业务关停与恢复
var message_aqld=[{"name_ld":"安全漏洞","effect_com":"45","effect_room":"787"}];//安全漏洞
var message_ycll=[{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"}];//异常流量
var message_fxfwq=[{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"},{"idc_name":"惠州idc1","idc_room":"机房1","com_name":"baidu.com","beian":"惠州备案信息1","process":"未处理"}];//风险服务器

//IDC安全报告
var message_day=[{"title":"惠州市IDC安全报告20180312-综合安全报告","periods":"第001期","range":"2018-03-14"},{"title":"惠州市IDC安全报告20180317-综合安全报告","periods":"第002期","range":"2018-03-14"}];
var message_week=[{"title":"惠州市IDC安全报告20180312-综合安全报告","periods":"第001期","range":"2018-03-14"},{"title":"惠州市IDC安全报告20180317-综合安全报告","periods":"第002期","range":"2018-03-14"},{"title":"惠州市IDC安全报告20180312-综合安全报告","periods":"第001期","range":"2018-03-14"},{"title":"惠州市IDC安全报告20180317-综合安全报告","periods":"第002期","range":"2018-03-14"}];
var message_month=[{"title":"惠州市IDC安全报告20180312-综合安全报告","periods":"第001期","range":"2018-03-14"},{"title":"惠州市IDC安全报告20180317-综合安全报告","periods":"第002期","range":"2018-03-14"},{"title":"惠州市IDC安全报告20180312-综合安全报告","periods":"第001期","range":"2018-03-14"},{"title":"惠州市IDC安全报告20180317-综合安全报告","periods":"第002期","range":"2018-03-14"},{"title":"惠州市IDC安全报告20180312-综合安全报告","periods":"第001期","range":"2018-03-14"},{"title":"惠州市IDC安全报告20180317-综合安全报告","periods":"第002期","range":"2018-03-14"}];
$(function(){
	Map_city('map_city',rawData_city,"惠州市",geoCoordMap,null);
	//加载基础数据
	showData();
	//加载柱状图
	load_bar();
	//加载table
	comprehensive_Rank(message_xxaq,'xingxianquan');
	comprehensive_Rank(message_wlaq,'wangluoanquan');
	comprehensive_Rank(message_wba,'weibeian');
	comprehensive_Rank(message_zgcl,'zhenggaichuli');
	comprehensive_Rank2(message_ywgtyhf,'yewuhuifuyushouli');
	comprehensive_Rank3(message_aqld,'anquanloudong');
	comprehensive_Rank(message_ycll,'yichangliulian');
	comprehensive_Rank(message_fxfwq,'fengxiangfuwuqi');
	//默认加载日报内容
	comprehensive_Rank5(message_day,'anquanbaogao');
	choosetime();
	//复选框选中事件
	checkType();
});

function showData(){
	$("#zhaqsjs").text(121);
	$("#wba").text(101);
	$("#hdd").text(1);
	$("#zwk").text(2);
	$("#fqdl").text(3);
	$("#zsrq").text(92);
	$("#hkkz").text(1);
	$("#hcml").text(45);
	$("#nbgj").text(8);
	$("#wbasj").text("458件");
	$("#xxaqsj").text("32件");
	$("#wlaqsj").text("58件");
	$("#yys").text("2个");
	$("#jf").text("58个");
	$("#ybaym").text("31456");
}
function load_bar(){
	Map_safeTrend('aqsjqs_content',pre,now);
}
//开始加载table的排名顺序
function comprehensive_Rank(message,classname){
	$("#"+classname).empty();
	var tab = $("#"+classname);
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<li><div>"+message[i].idc_name+"</div><div>"+message[i].idc_room+"</div><div>"+message[i].com_name+"</div><div>"+message[i].beian+"</div><div>"+message[i].process+"</div></li>");
		$(tab).append($(tdhtml));
	}
};
//开始加载table的排名顺序
function comprehensive_Rank2(message,classname){
	var tab = $("#"+classname);
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<li><div>"+message[i].idc_name+"</div><div>"+message[i].idc_room+"</div><div>"+message[i].having+"</div><div>"+message[i].sqhf+"</div><div>"+message[i].ysl+"</div><div>"+message[i].shz+"</div><div>"+message[i].ysh+"</div></li>");
		$(tab).append($(tdhtml));
	}
};
//开始加载table的排名顺序
function comprehensive_Rank3(message,classname){
	var tab = $("#"+classname);
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<li><div>"+message[i].name_ld+"</div><div>"+message[i].effect_com+"</div><div>"+message[i].effect_room+"</div></li>");
		$(tab).append($(tdhtml));
	}
};
//开始加载table的排名顺序
function comprehensive_Rank5(message,classname){
	$("#anquanbaogao tr:gt(0)").remove();
	var tab = $("#"+classname);
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<tr><td>"+message[i].title+"</td><td>"+message[i].periods+"</td><td>"+message[i].range+"</td><td><a href=''>下载</a></td></tr>");
		$(tab).append($(tdhtml));
	}
};
//IDC安全报告的时间点击事件
function choosetime(){
	var obj_lis = document.getElementById("report_cycle").getElementsByTagName("li");
    for(i=0;i<obj_lis.length;i++){
        obj_lis[i].onclick = function(){
            var time = this.innerHTML;
            $(this).css("border-bottom","2px solid rgb(0,90,160)");
            $(this).siblings().css("border-bottom","");
            //加载table 数据
            if(time=="日报"){
            	comprehensive_Rank5(message_day,'anquanbaogao')
            }
            if(time=="周报"){
            	comprehensive_Rank5(message_week,'anquanbaogao')
            }
            if(time=="月报"){
            	comprehensive_Rank5(message_month,'anquanbaogao')
            }
        }
    }
}
function checkType(){
	var s = $("input[name='check1']");
    s.each(function(i) {
            $(this).click(function(){
//            	var SelectFalse = true; //用于判断是否被选择条件
            	var arr=[];
                if(this.checked==true){
                      var val = this.value;
                      if(val==0){
                    	  flag1=1;
                      }
                      if(val==1){
                    	  flag2=1;
                      }
                      if(val==2){
                    	  flag3=1;
                      }
                }else{
                	var val = this.value;
                    if(val==0){
                  	  flag1=0;
                    }
                    if(val==1){
                  	  flag2=0;
                    }
                    if(val==2){
                  	  flag3=0;
                    }
                }
                if(flag1==0&&flag2==0&&flag3==0){
                	var val = this.value;
                	if(val==0){
                  	  flag1=1;
                    }
                    if(val==1){
                  	  flag2=1;
                    }
                    if(val==2){
                  	  flag3=1;
                    }
                	alert("对不起：至少要选一项");
                	return false
                }
                //调用函数
                for(var i=0; i<message_xxaq.length;i++){
                	if(flag1){
                		if(message_xxaq[i].process=='未处理'){
                			arr[arr.length]=message_xxaq[i];
                			continue;
                		}
                		
                	}
                	if(flag2){
                		if(message_xxaq[i].process=='已关停'){
                			arr[arr.length]=message_xxaq[i];
                			continue;
                		}
                		
                	}
                	if(flag3){
                		if(message_xxaq[i].process=='已下发'){
                			arr[arr.length]=message_xxaq[i];
                			continue;
                		}
                		
                	}
                }
                
                comprehensive_Rank(arr,'xingxianquan');
             });
        });
    var s2 = $("input[name='check2']");
    s2.each(function(i) {
            $(this).click(function(){
            	var arr=[];
                if(this.checked==true){
                      var val = this.value;
                      if(val==0){
                    	  flag4=1;
                      }
                      if(val==1){
                    	  flag5=1;
                      }
                      if(val==2){
                    	  flag6=1;
                      }
                }else{
                	var val = this.value;
                    if(val==0){
                  	  flag4=0;
                    }
                    if(val==1){
                  	  flag5=0;
                    }
                    if(val==2){
                  	  flag6=0;
                    }
                }
                if(flag4==0&&flag5==0&&flag6==0){
                	var val = this.value;
                	if(val==0){
                  	  flag4=1;
                    }
                    if(val==1){
                  	  flag5=1;
                    }
                    if(val==2){
                  	  flag6=1;
                    }
                    alert(flag4+"--"+flag5+"--"+flag6);
                	alert("对不起：至少要选一项");
                	return false
                }
                //调用函数
                for(var i=0; i<message_wlaq.length;i++){
                	if(flag4){
                		if(message_wlaq[i].process=='未处理'){
                			arr[arr.length]=message_wlaq[i];
                			continue;
                		}
                		
                	}
                	if(flag5){
                		if(message_wlaq[i].process=='已关停'){
                			arr[arr.length]=message_wlaq[i];
                			continue;
                		}
                		
                	}
                	if(flag6){
                		if(message_wlaq[i].process=='已下发'){
                			arr[arr.length]=message_wlaq[i];
                			continue;
                		}
                		
                	}
                }
                
                comprehensive_Rank(arr,'wangluoanquan');
             });
        });
    var s3 = $("input[name='check3']");
    s3.each(function(i) {
            $(this).click(function(){
//            	var SelectFalse = true; //用于判断是否被选择条件
            	var arr=[];
                if(this.checked==true){
                      var val = this.value;
                      if(val==0){
                    	  flag7=1;
                      }
                      if(val==1){
                    	  flag8=1;
                      }
                      if(val==2){
                    	  flag9=1;
                      }
                }else{
                	var val = this.value;
                    if(val==0){
                  	  flag7=0;
                    }
                    if(val==1){
                  	  flag8=0;
                    }
                    if(val==2){
                  	  flag9=0;
                    }
                }
                if(flag7==0&&flag8==0&&flag9==0){
                	var val = this.value;
                	if(val==0){
                  	  flag7=1;
                    }
                    if(val==1){
                  	  flag8=1;
                    }
                    if(val==2){
                  	  flag9=1;
                    }
                	alert("对不起：至少要选一项");
                	return false
                }
                //调用函数
                for(var i=0; i<message_wba.length;i++){
                	if(flag7){
                		if(message_wba[i].process=='未处理'){
                			arr[arr.length]=message_wba[i];
                			continue;
                		}
                		
                	}
                	if(flag8){
                		if(message_wba[i].process=='已关停'){
                			arr[arr.length]=message_wba[i];
                			continue;
                		}
                		
                	}
                	if(flag9){
                		if(message_wba[i].process=='已下发'){
                			arr[arr.length]=message_wba[i];
                			continue;
                		}
                		
                	}
                }
                
                comprehensive_Rank(arr,'weibeian');
             });
        });
}

//地图下面的点击事件切换
$(".addorless_city").click(function(){
	if(num==0){
		$("#map_city").css("display","none");
		$("#curve_city").css("display","block");
		line('curve_city',arr,'惠州市IDC安全态势');
		num=num+1;
		$(this).html("<");
	}else{
		$("#map_city").css("display","block");
		$("#curve_city").css("display","none");
		Map_city('map_city',rawData_city,"惠州市",geoCoordMap,null);
		num=num-1;
		$(this).html(">");
	}
});
