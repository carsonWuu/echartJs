var city="";
//地图点击事件
function clickcity(city){
	city=city;
	//改变下拉框的值
	alert(city);
	toucheachdata(city);
	//加载地级市
//	loadcitymap(city);
}
//下拉框选择改变事件
function show_sub(v){     
	city=v;
	//加载地级市
	loadcitymap(city);
}

function loadcitymap(city){
//	alert(city);
}
//$(function(){
//	toucheachdata()
//});
function toucheachdata(city){
    $("#province option").each(function() {
       var chose = $(this).attr("value");
       alert(chose);
//       if(chose==city){
//    	   $("#province select").removeAttr("selected");
//    	   var value = $(this);
//    	   alert(value);
//       }
    });
//    var sel = $("select").val();
//    alert("多选列表所有的value值:"+all+"，其中被选中的是:"+sel+"。");
}