function line(id,arr,title){
    var name=arr.map(a=>a.name),
        data=arr.map(a=>a.value);
    var chart =  echarts.init(document.getElementById(id));
    var option={
        title:{
            text:title,
            show:true,
            x:0,
            textStyle:{
                color:'rgb(0, 81, 175)',
                fontSize:15
            }
        },
        tooltip:{},
        roam:true,
        xAxis: {
            type: 'category',
            axisLine: {
            show: true
            },
            axisTick: {
                show: false,
                alignWithLabel: true
            },
            axisLabel: {
                textStyle: {
                    color: "#f00"
                }
            },
            data: name
        },
        yAxis: {

            type: 'value'
        },
        series: [{
        	background:'#fff',
            data: data,
            type: 'line',
            smooth: true
        }]

    };
    chart.setOption(option);
}
