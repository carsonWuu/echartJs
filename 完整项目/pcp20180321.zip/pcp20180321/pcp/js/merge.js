/**
 * 读取服务器json文件
 */
var NBGJ,SS1_CLZ,SS2_CLZ,ZSRQ,
WBA_YCL,ZSRQ_YCL,FQDL,SS2,SS1,HCML_CLZ,WBA_CLZ,HCML,
HKKZ_CLZ,HCML_YCL,FQDL_CLZ,HKKZ,SS2_YCL,FQDL_YCL,NBGJ_YCL,
WBA,CREATTIME,NBGJ_CLZ,SS1_YCL,ZSRQ_CLZ,HKKZ_YCL;

var level1={};
var AQSJZS,WCLSJS,YYSS,IDCJFS,WZBAS,ZCYMS,
	AQSJZSpre=[],AQSJZScur=[];



var IDC=[];
function ajax_leftTop(url){
	
	
	$.ajax({
		type:'GET',
		url:url,
		dataType:'json',
		error:errorFunc,
		success:successFunc,
		
	})
}
function successFunc(data){
	//console.log(data);
	var data1=data.SMMSEVENT;
	level1.NBGJ=data1.NBGJ,level1.SS1_CLZ=data1.SS1_CLZ,level1.SS2_CLZ=data1.SS2_CLZ,level1.ZSRQ=data1.ZSRQ,level1.
	WBA_YCL=data1.WBA_YCL,level1.ZSRQ_YCL=data1.ZSRQ_YCL,level1.FQDL=data1.FQDL,level1.SS2=data1.SS2,level1.SS1=data1.SS1,level1.
	HCML_CLZ=data1.HCML_CLZ,level1.WBA_CLZ=data1.WBA_CLZ,level1.HCML=data1.HCML,level1.
	HKKZ_CLZ=data1.HKKZ_CLZ,level1.HCML_YCL=data1.HCML_YCL,level1.FQDL_CLZ=data1.FQDL_CLZ,level1.
	HKKZ=data1.HKKZ,level1.SS2_YCL=data1.SS2_YCL,level1.FQDL_YCL=data1.FQDL_YCL,level1.NBGJ_YCL=data1.NBGJ_YCL,level1.
	WBA=data1.WBA,level1.CREATTIME=data1.CREATTIME,level1.NBGJ_CLZ=data1.NBGJ_CLZ,level1.SS1_YCL=data1.SS1_YCL,level1.
	ZSRQ_CLZ=data1.ZSRQ_CLZ,level1.HKKZ_YCL=data1.HKKZ_YCL;
	console.log(data1);
	console.log(level1);
	var IDC=data.SMMSIDCEVENTTOP10;
	
};
function errorFunc(){
	alert('Error:\n数据读取失败');
}


//function ajax_rightTop(url){
//	
//	
//	$.ajax({
//		type:'GET',
//		    
//		url:url,
//		dataType:'json',
//		
//		success:successFunc2,
//		error:errorFunc,
//		
//	})
//}
//
//function successFunc2(data){
//	var year=new Date;
//	year=year.getFullYear();
//	
//	alert(year);
//}


//ajax_rightTop(url);

function Province(url1,url2,url3,url4,url5){
	url1='http://172.18.2.189/SPT/SPT/SptProvEventBiz/getSptProEventJson';
	url2='http://172.18.2.189/SPT/SPT/SptCitySumYbBiz/getSptCitySumYbJson';
	url3='http://172.18.2.189/SPT/SPT/SptCityEventBiz/getJsonSptCitySumWx';
	url4='http://172.18.2.189/SPT/SPT/SptCityRectifyBiz/getSptCityRectifyJson';
	url5='http://172.18.2.189/SPT/SPT/SptCloseOpenBiz/getSptGtHfJson';
	
	
	url1='../js/Pdata1.json';
	url2='../js/Pdata2.json';
	url3='../js/Pdata3.json';
	url4='../js/Pdata4.json';
	url5='../js/Pdata5.json';
	$.ajax({
		type:'GET',
		url:url1,
		dataType:'json',
		success:success1,
		error:errorFunc,
	});
	$.ajax({
		type:'GET',
		url:url2,
		dataType:'json',
		success:success2,
		error:errorFunc,
	});
	$.ajax({
		type:'GET',
		url:url3,
		dataType:'json',
		success:success3,
		error:errorFunc,
	});
	
	$.ajax({
		type:'GET',
		url:url4,
		dataType:'json',
		success:success4,
		error:errorFunc,
	});
	
	$.ajax({
		type:'GET',
		url:url5,
		dataType:'json',
		success:success5,
		error:errorFunc,
	});
	function ZHAQSJ_count(SPTPROEVENT){
		
		$('#zhaqsjs').text(SPTPROEVENT.ZHAQSJ);
		$('#wba').text(SPTPROEVENT.WBA);
		$('#hdd').text(SPTPROEVENT.SS2);
		$('#zwk').text(SPTPROEVENT.SS1);
		$('#fqdl').text(SPTPROEVENT.FQDL);
		$('#zsrq').text(SPTPROEVENT.ZSRQ);
		$('#hkkz').text(SPTPROEVENT.HKKZ);
		$('#hcml').text(SPTPROEVENT.HCML);
		$('#nbgj').text(SPTPROEVENT.NBGJ);
	};
	function success1(data){//左上角安全态势地图
		var SPTPROEVENT={},SPTCITYEVENTTOP10=[],SPTCITYEVENTALL=[];
		SPTPROEVENT=data.SPTPROEVENT[0];//1.全省IDC安全态势：（八大事件）:SPTPROEVENT：WBA+SS2+SS1+FQDL+ZSRQ+HKKZ+HCML+NBGJ
		SPTCITYEVENTTOP10=data.SPTCITYEVENTTOP10;//用于综合安全事件影响排名10
		SPTCITYEVENTALL=data.SPTCITYEVENTALL;//用于条形图，显示给个地市的综合安全地市数量
		//console.log(data);
		var cityData=[];
		for(var i=0;i<SPTCITYEVENTALL.length;i++){
			cityData.push({name:SPTCITYEVENTALL[i].CITY_NAME.slice(-3),value:SPTCITYEVENTALL[i].CITYEVENTALL});
		}
		Map('map_province',cityData,cityData);
//		$('#zhexiantu').css('height','10px').css('width','20px');
//		line('zhexiantu',arr,'');
		$(".alldata").click(function(){
			if(num==0){
				$("#map_province").css("display","none");
				$("#curve_province").css("display","block");
				line('curve_province',arr,'全省IDC安全态势');
				num=num+1;
				$(".addorless").html("<");
			}else{
				$("#map_province").css("display","block");
				$("#curve_province").css("display","none");
				Map('map_province',cityData,cityData);
				num=num-1;
				$(".addorless").html(">");
			}
		});
		
		ZHAQSJ_count(SPTPROEVENT);
		setInterval('autoScroll(".maquee")',3000);
		setInterval('autoScroll(".maquee2")',3000);
		
		
	}
	function IDCjierutongji(CITY_TOTAL){
		$('#idcyys').html(CITY_TOTAL.YYSSALL+'<span>个</span>');
		$('#idcjf').html(CITY_TOTAL.IDCJFSALL+'<span>个</span>');
		$('#idcybaym').html(CITY_TOTAL.WZBASALL+'<span>个</span>');	
	};
	function IDC_city(CITY_SUM){
		/*
		 *  <ul>
			<li>
				<div>东莞市</div>
				<div>60</div>
				<div>89</div>
				<div>54</div>
			</li> 
		 */
		var txt='';
		txt+='<ul>';
		for(var i=0;i<CITY_SUM.length;i++){
			txt+='<li>';
			txt+='<div>';
			txt+=CITY_SUM[i].CITY_NAME.slice(-3);
			txt+='</div>';
			
			txt+='<div>';
			txt+=CITY_SUM[i].YYSS;
			txt+='</div>';
			
			txt+='<div>';
			txt+=CITY_SUM[i].IDCJFS;
			txt+='</div>';
			
			txt+='<div>';
			txt+=CITY_SUM[i].WZBAS;
			txt+='</div>';
			
			txt+='</li>';
			
		}
		txt+='</ul>';
		$('#idc_city').html(txt);
	};
	function success2(data){//右上角IDC介入统计
		IDCjierutongji(data.CITY_TOTAL);//接入统计
		
		IDC_city(data.CITY_SUM);
		
		
		//网络安全事件趋势条形图
		var year=new Date();
		var nowYear= parseInt(year.getFullYear());
		preYear=nowYear-1;
		//alert(preYear)
		
		var predata=[],nowdata=[];
		for(var i=0;i<12;i++){predata[i]=0;nowdata[i]=0;}
		for(var i=0;i<data.CITY_SUM_YB.length;i++){
			if(data.CITY_SUM_YB[i].NF==preYear){predata[data.CITY_SUM_YB[i].YF-1]=data.CITY_SUM_YB[i].AQSJZS;}
			else if(data.CITY_SUM_YB[i].NF==nowYear){nowdata[data.CITY_SUM_YB[i].YF-1]=data.CITY_SUM_YB[i].AQSJZS;}
		}
		
		Map_safeTrend('content',preYear+'年',nowYear+'年',predata,nowdata);
	}
	function success3(data){//省威胁态势
		
	}
	function success4(data){//整改处理
		var txt='';
		txt+='<ul>';
		for(var i=0;i<data.length;i++){
			txt+='<li>';
			txt+='<div>';
			txt+=data[i].CITY_NAME.slice(-3);
			txt+='</div>';
			
			txt+='<div>';
			txt+=data[i].DZG;
			txt+='</div>';
			
			txt+='<div>';
			txt+=data[i].ZGZ;
			txt+='</div>';
			
			txt+='<div>';
			txt+=data[i].YZG;
			txt+='</div>';
			
			txt+='</li>';
			
		}
		txt+='</ul>';
		$('#zhenggaichuli').html(txt);
	}
	function success5(data){//业务关停与恢复
		var txt='';
		txt+='<ul>';
		for(var i=0;i<data.length;i++){
			txt+='<li>';
			txt+='<div>';
			txt+=data[i].CITY_NAME.slice(-3);
			txt+='</div>';
			
			txt+='<div>';
			txt+=data[i].GTZ;
			txt+='</div>';
			
			txt+='<div>';
			txt+=data[i].SQHF;
			txt+='</div>';
			
			txt+='<div>';
			txt+=data[i].YSL;
			txt+='</div>';
			
			txt+='<div>';
			txt+=data[i].SHZ;
			txt+='</div>';
			
			txt+='<div>';
			txt+=data[i].YHF;
			txt+='</div>';
			
			txt+='</li>';
			
		}
		txt+='</ul>';
		$('#yewuguantingyuhuifu').html(txt);
	}
	
//	$(function(){
//		/*
//		 * 地图加载
//		 * rawData  地图上的标注
//		 * rawData  top10
//		 * */
//		Map('map',rawData,rawData);
//		//定时轮播table数据
////		setInterval('autoScroll(".maquee")',3000);
////		setInterval('autoScroll(".maquee2")',3000);
////		//加载柱状图
////		Map_safeTrend('content',pre,now);
////		//默认加载信息安全事件
////		pie_bar('wxts_echarts',data,'信息安全事件Top10');
////		//全省IDC威胁态势的点击事件
////		typechoose();
////		//默认加载全部城市的日报
////		loadtables(city,time);
////		//选择日报周报月报事件
////		choosetime();
////		//选择城市事件
////		choosecity();
//	});
	
}
Province('1','2','3','4','5');




var city="全部";
var time="日报";
var message ="";
var num = 0;
var data=[{name:'涉黄',data:[
    {name: '珠海市',value:54},
    {name: '广州市',value: 57},
    {name: '中山市',value:45},
    {name: '佛山市',value: 20},
    {name: '清远市',value:12},
    {name: '梅州市',value: 88},
    {name: '汕头市',value:56},
    {name: '东莞市',value: 10},
    {name: '惠州市',value:31},
    {name: '湛江市',value: 56},
    {name: '深圳市',value: 87}
]},{name:'涉赌',data:[
    {name: '珠海市',value:4},
    {name: '广州市',value: 5},
    {name: '中山市',value:1},
    {name: '佛山市',value: 45},
    {name: '清远市',value:78},
    {name: '梅州市',value: 14},
    {name: '汕头市',value:35},
    {name: '东莞市',value: 48},
    {name: '惠州市',value:12},
    {name: '湛江市',value: 54},
    {name: '深圳市',value: 18},
    {name: '汕尾市',value: 7}
    ]
},{name:'涉毒',data:[
    {name: '珠海市',value:54},
    {name: '广州市',value: 57},
    {name: '中山市',value:45},
    {name: '佛山市',value: 20},
    {name: '清远市',value:12},
    {name: '梅州市',value: 88},
    {name: '汕头市',value:56},
    {name: '东莞市',value: 10},
    {name: '惠州市',value:31},
    {name: '湛江市',value: 56},
    {name: '深圳市',value: 87}
]},{name:'涉政',data:[
    {name: '珠海市',value:4},
    {name: '广州市',value: 5},
    {name: '中山市',value:1},
    {name: '佛山市',value: 45},
    {name: '清远市',value:78},
    {name: '梅州市',value: 14},
    {name: '汕头市',value:35},
    {name: '东莞市',value: 48},
    {name: '惠州市',value:12},
    {name: '湛江市',value: 54},
    {name: '深圳市',value: 18},
    {name: '汕尾市',value: 7}
    ]},{name:'涉稳',data:[
    {name: '珠海市',value:54},
    {name: '广州市',value: 57},
    {name: '中山市',value:45},
    {name: '佛山市',value: 20},
    {name: '清远市',value:12},
    {name: '梅州市',value: 88},
    {name: '汕头市',value:56},
    {name: '东莞市',value: 10},
    {name: '惠州市',value:31},
    {name: '湛江市',value: 56},
    {name: '深圳市',value: 87}
]},{name:'涉恐',data:[
    {name: '珠海市',value:4},
    {name: '广州市',value: 5},
    {name: '中山市',value:1},
    {name: '佛山市',value: 45},
    {name: '清远市',value:78},
    {name: '梅州市',value: 14},
    {name: '汕头市',value:35},
    {name: '东莞市',value: 48},
    {name: '惠州市',value:12},
    {name: '湛江市',value: 54},
    {name: '深圳市',value: 18},
    {name: '汕尾市',value: 7}
    ]}
,{name:'翻墙代理',data:[
    {name: '珠海市',value:4},
    {name: '广州市',value: 5},
    {name: '中山市',value:1},
    {name: '佛山市',value: 45},
    {name: '清远市',value:78},
    {name: '梅州市',value: 14},
    {name: '汕头市',value:35},
    {name: '东莞市',value: 48},
    {name: '惠州市',value:12},
    {name: '湛江市',value: 54},
    {name: '深圳市',value: 18},
    {name: '汕尾市',value: 7}
    ]}
];
var rawData = [
    {name: '珠海市',value:130},
    {name: '广州市',value: 120},
    {name: '中山市',value:110},
    {name: '佛山市',value: 100},
    {name: '清远市',value:90},
    {name: '梅州市',value: 70},
    {name: '汕头市',value:80},
    {name: '东莞市',value: 30},
    {name: '惠州市',value:50},
    {name: '湛江市',value: 40},
    {name: '深圳市',value: 60}
    ];

var arr=[{name:'1号',value:30},{name:'2号',value:20},{name:'3号',value:10},{name:'4号',value:50}];
var pre=[100.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3],
now=[2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8];
$(function(){
	/*
	 * 地图加载
	 * rawData  地图上的标注
	 * rawData  top10
	 * */
	//Map('map_province',rawData,rawData);
	//定时轮播table数据
	//setInterval('autoScroll(".maquee")',3000);
	//setInterval('autoScroll(".maquee2")',3000);
	//加载柱状图
	//Map_safeTrend('content',pre,now);
	//默认加载信息安全事件
	pie_bar('wxts_echarts',data,'信息安全事件Top10');
	//全省IDC威胁态势的点击事件
	typechoose();
	//默认加载全部城市的日报
	loadtables(city,time);
	//选择日报周报月报事件
	choosetime();
	//选择城市事件
	choosecity();
});
//地图下面的点击事件切换


//IDC安全报告的城市点击事件
function choosecity(){
	var obj_lis = document.getElementById("report_city").getElementsByTagName("td");
    for(i=0;i<obj_lis.length;i++){
        obj_lis[i].onclick = function(){
        	city = this.innerHTML;
        	$(obj_lis).css("background-color","");
            $(this).css("background-color","rgb(0,72,128)");
            //加载table 数据
        	loadtables(city,time);
        }
    }
}
//IDC安全报告的时间点击事件
function choosetime(){
	var obj_lis = document.getElementById("report_cycle").getElementsByTagName("li");
    for(i=0;i<obj_lis.length;i++){
        obj_lis[i].onclick = function(){
            time = this.innerHTML;
            $(this).css("border-bottom","2px solid rgb(0,90,160)");
            $(this).siblings().css("border-bottom","");
            //加载table 数据
        	loadtables(city,time);
        }
    }
}
//全省IDC威胁态势的点击事件
function typechoose(){
	var obj_lis = document.getElementById("wxts_choose").getElementsByTagName("li");
    for(i=0;i<obj_lis.length;i++){
        obj_lis[i].onclick = function(){
            var type = this.innerHTML;
            $(this).css("background-color","rgb(74,144,226)");
            $(this).siblings().css("background-color","");
            //加载echarts
        	if(type=="信息安全事件"){
        		data=[{name:'涉黄',data:[
        		    {name: '珠海市',value:54},
        		    {name: '广州市',value: 57},
        		    {name: '中山市',value:45},
        		    {name: '佛山市',value: 20},
        		    {name: '清远市',value:12},
        		    {name: '梅州市',value: 88},
        		    {name: '汕头市',value:56},
        		    {name: '东莞市',value: 10},
        		    {name: '惠州市',value:31},
        		    {name: '湛江市',value: 56},
        		    {name: '深圳市',value: 87}
        		]
        		},
        		{name:'涉赌',data:[
        		    {name: '珠海市',value:4},
        		    {name: '广州市',value: 5},
        		    {name: '中山市',value:1},
        		    {name: '佛山市',value: 45},
        		    {name: '清远市',value:78},
        		    {name: '梅州市',value: 14},
        		    {name: '汕头市',value:35},
        		    {name: '东莞市',value: 48},
        		    {name: '惠州市',value:12},
        		    {name: '湛江市',value: 54},
        		    {name: '深圳市',value: 18},
        		    {name: '汕尾市',value: 7}
        		    ]
        		},
        		{name:'涉毒',data:[
        		    {name: '珠海市',value:54},
        		    {name: '广州市',value: 57},
        		    {name: '中山市',value:45},
        		    {name: '佛山市',value: 20},
        		    {name: '清远市',value:12},
        		    {name: '梅州市',value: 88},
        		    {name: '汕头市',value:56},
        		    {name: '东莞市',value: 10},
        		    {name: '惠州市',value:31},
        		    {name: '湛江市',value: 56},
        		    {name: '深圳市',value: 87}
        		]
        		},
        		{name:'涉政',data:[
        		    {name: '珠海市',value:4},
        		    {name: '广州市',value: 5},
        		    {name: '中山市',value:1},
        		    {name: '佛山市',value: 45},
        		    {name: '清远市',value:78},
        		    {name: '梅州市',value: 14},
        		    {name: '汕头市',value:35},
        		    {name: '东莞市',value: 48},
        		    {name: '惠州市',value:12},
        		    {name: '湛江市',value: 54},
        		    {name: '深圳市',value: 18},
        		    {name: '汕尾市',value: 7}
        		    ]
        		},{name:'涉稳',data:[
        		    {name: '珠海市',value:54},
        		    {name: '广州市',value: 57},
        		    {name: '中山市',value:45},
        		    {name: '佛山市',value: 20},
        		    {name: '清远市',value:12},
        		    {name: '梅州市',value: 88},
        		    {name: '汕头市',value:56},
        		    {name: '东莞市',value: 10},
        		    {name: '惠州市',value:31},
        		    {name: '湛江市',value: 56},
        		    {name: '深圳市',value: 87}
        		]
        		},
        		{name:'涉恐',data:[
        		    {name: '珠海市',value:4},
        		    {name: '广州市',value: 5},
        		    {name: '中山市',value:1},
        		    {name: '佛山市',value: 45},
        		    {name: '清远市',value:78},
        		    {name: '梅州市',value: 14},
        		    {name: '汕头市',value:35},
        		    {name: '东莞市',value: 48},
        		    {name: '惠州市',value:12},
        		    {name: '湛江市',value: 54},
        		    {name: '深圳市',value: 18},
        		    {name: '汕尾市',value: 7}
        		    ]
        		},
        		{name:'翻墙代理',data:[
        		    {name: '珠海市',value:4},
        		    {name: '广州市',value: 5},
        		    {name: '中山市',value:1},
        		    {name: '佛山市',value: 45},
        		    {name: '清远市',value:78},
        		    {name: '梅州市',value: 14},
        		    {name: '汕头市',value:35},
        		    {name: '东莞市',value: 48},
        		    {name: '惠州市',value:12},
        		    {name: '湛江市',value: 54},
        		    {name: '深圳市',value: 18},
        		    {name: '汕尾市',value: 7}
        		    ]
        		}
        		];
        		pie_bar('wxts_echarts',data,'信息安全事件Top10');
        	}
        	if(type=="网络安全事件"){
        		data = [ {
    				name : '遭受入侵',
    				data : [ {
    					name : '珠海市',
    					value : 130
    				}, {
    					name : '广州市',
    					value : 50
    				}, {
    					name : '中山市',
    					value : 30
    				}, {
    					name : '佛山市',
    					value : 50
    				}, {
    					name : '清远市',
    					value : 30
    				}, {
    					name : '梅州市',
    					value : 50
    				}, {
    					name : '汕头市',
    					value : 30
    				}, {
    					name : '东莞市',
    					value : 50
    				}, {
    					name : '惠州市',
    					value : 30
    				}, {
    					name : '湛江市',
    					value : 50
    				}, {
    					name : '深圳市',
    					value : 50
    				} ]
    			}, {
    				name : '黑客控制',
    				data : [ {
    					name : '珠海市',
    					value : 130
    				}, {
    					name : '广州市',
    					value : 100
    				}, {
    					name : '中山市',
    					value : 30
    				}, {
    					name : '佛山市',
    					value : 50
    				}, {
    					name : '清远市',
    					value : 30
    				}, {
    					name : '梅州市',
    					value : 50
    				}, {
    					name : '汕头市',
    					value : 30
    				}, {
    					name : '东莞市',
    					value : 50
    				}, {
    					name : '惠州市',
    					value : 30
    				}, {
    					name : '湛江市',
    					value : 50
    				}, {
    					name : '深圳市',
    					value : 50
    				}, {
    					name : '汕尾市',
    					value : 50
    				} ]
    			}, {
    				name : '黑客牟利',
    				data : [ {
    					name : '珠海市',
    					value : 130
    				}, {
    					name : '广州市',
    					value : 100
    				}, {
    					name : '中山市',
    					value : 30
    				}, {
    					name : '佛山市',
    					value : 50
    				}, {
    					name : '清远市',
    					value : 30
    				}, {
    					name : '梅州市',
    					value : 50
    				}, {
    					name : '汕头市',
    					value : 30
    				}, {
    					name : '东莞市',
    					value : 50
    				}, {
    					name : '惠州市',
    					value : 30
    				}, {
    					name : '湛江市',
    					value : 50
    				}, {
    					name : '深圳市',
    					value : 50
    				}, {
    					name : '汕尾市',
    					value : 50
    				} ]
    			} , {
    				name : '内部攻击',
    				data : [ {
    					name : '珠海市',
    					value : 130
    				}, {
    					name : '广州市',
    					value : 100
    				}, {
    					name : '中山市',
    					value : 30
    				}, {
    					name : '佛山市',
    					value : 50
    				}, {
    					name : '清远市',
    					value : 30
    				}, {
    					name : '梅州市',
    					value : 50
    				}, {
    					name : '汕头市',
    					value : 30
    				}, {
    					name : '东莞市',
    					value : 50
    				}, {
    					name : '惠州市',
    					value : 30
    				}, {
    					name : '湛江市',
    					value : 50
    				}, {
    					name : '深圳市',
    					value : 50
    				}, {
    					name : '汕尾市',
    					value : 50
    				} ]
    			}];
        		pie_bar('wxts_echarts',data,'网络安全事件Top10');
        	}
        	if(type=="未备案事件"){
        		data = [ {
    				name : '备案',
    				data : [ {
    					name : '珠海市',
    					value : 130
    				}, {
    					name : '广州市',
    					value : 50
    				}, {
    					name : '中山市',
    					value : 30
    				}, {
    					name : '佛山市',
    					value : 50
    				}, {
    					name : '清远市',
    					value : 30
    				}, {
    					name : '梅州市',
    					value : 50
    				}, {
    					name : '汕头市',
    					value : 30
    				}, {
    					name : '东莞市',
    					value : 50
    				}, {
    					name : '惠州市',
    					value : 30
    				}, {
    					name : '湛江市',
    					value : 50
    				}, {
    					name : '深圳市',
    					value : 50
    				} ]
    			}, {
    				name : '未备案',
    				data : [ {
    					name : '珠海市',
    					value : 130
    				}, {
    					name : '广州市',
    					value : 100
    				}, {
    					name : '中山市',
    					value : 30
    				}, {
    					name : '佛山市',
    					value : 50
    				}, {
    					name : '清远市',
    					value : 30
    				}, {
    					name : '梅州市',
    					value : 50
    				}, {
    					name : '汕头市',
    					value : 30
    				}, {
    					name : '东莞市',
    					value : 50
    				}, {
    					name : '惠州市',
    					value : 30
    				}, {
    					name : '湛江市',
    					value : 50
    				}, {
    					name : '深圳市',
    					value : 50
    				}, {
    					name : '汕尾市',
    					value : 50
    				} ]
    			} ];
        		pie_bar('wxts_echarts',data,'未备案事件Top10');
        	}
        }
    }
}

function loadtables(city,time){
	if(city=="全部"&&time=="日报"){
		message =[{"RANKING":1,"city":"广州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"},{"RANKING":2,"city":"珠海市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"},{"RANKING":3,"city":"深圳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="全部"&&time=="周报"){
		message =[{"RANKING":1,"city":"广州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"},{"RANKING":2,"city":"珠海市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="全部"&&time=="月报"){
		message =[{"RANKING":1,"city":"佛山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"},{"RANKING":2,"city":"惠州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="广州市"&&time=="日报"){//广州
		message =[{"RANKING":1,"city":"广州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="广州市"&&time=="周报"){
		message =[{"RANKING":1,"city":"广州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="广州市"&&time=="月报"){
		message =[{"RANKING":1,"city":"广州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="深圳市"&&time=="日报"){//深圳市
		message =[{"RANKING":1,"city":"深圳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="深圳市"&&time=="周报"){
		message =[{"RANKING":1,"city":"深圳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="深圳市"&&time=="月报"){
		message =[{"RANKING":1,"city":"深圳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="珠海市"&&time=="日报"){//珠海市
		message =[{"RANKING":1,"city":"珠海市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="珠海市"&&time=="周报"){
		message =[{"RANKING":1,"city":"珠海市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="珠海市"&&time=="月报"){
		message =[{"RANKING":1,"city":"珠海市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="揭阳市"&&time=="日报"){//揭阳市
		message =[{"RANKING":1,"city":"揭阳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="揭阳市"&&time=="周报"){
		message =[{"RANKING":1,"city":"揭阳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="揭阳市"&&time=="月报"){
		message =[{"RANKING":1,"city":"揭阳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="汕尾市"&&time=="日报"){//汕尾市
		message =[{"RANKING":1,"city":"汕尾市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="汕尾市"&&time=="周报"){//
		message =[{"RANKING":1,"city":"汕尾市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="汕尾市"&&time=="月报"){
		message =[{"RANKING":1,"city":"汕尾市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="汕头市"&&time=="日报"){//汕头市
		message =[{"RANKING":1,"city":"汕头市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="汕头市"&&time=="周报"){
		message =[{"RANKING":1,"city":"汕头市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="汕头市"&&time=="月报"){
		message =[{"RANKING":1,"city":"汕头市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="佛山市"&&time=="日报"){//佛山市
		message =[{"RANKING":1,"city":"佛山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="佛山市"&&time=="周报"){
		message =[{"RANKING":1,"city":"佛山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="佛山市"&&time=="月报"){
		message =[{"RANKING":1,"city":"佛山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="中山市"&&time=="日报"){//中山市
		message =[{"RANKING":1,"city":"中山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="中山市"&&time=="周报"){
		message =[{"RANKING":1,"city":"中山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="中山市"&&time=="月报"){
		message =[{"RANKING":1,"city":"中山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="湛江市"&&time=="日报"){//湛江市
		message =[{"RANKING":1,"city":"湛江市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="湛江市"&&time=="周报"){
		message =[{"RANKING":1,"city":"湛江市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="湛江市"&&time=="月报"){
		message =[{"RANKING":1,"city":"湛江市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="阳江市"&&time=="日报"){//阳江市
		message =[{"RANKING":1,"city":"阳江市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="阳江市"&&time=="周报"){
		message =[{"RANKING":1,"city":"阳江市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="阳江市"&&time=="月报"){
		message =[{"RANKING":1,"city":"阳江市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="茂名市"&&time=="日报"){//茂名市
		message =[{"RANKING":1,"city":"茂名市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="茂名市"&&time=="周报"){
		message =[{"RANKING":1,"city":"茂名市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="茂名市"&&time=="月报"){
		message =[{"RANKING":1,"city":"茂名市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="韶关市"&&time=="日报"){//韶关市
		message =[{"RANKING":1,"city":"韶关市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="韶关市"&&time=="周报"){
		message =[{"RANKING":1,"city":"韶关市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="韶关市"&&time=="月报"){
		message =[{"RANKING":1,"city":"韶关市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="清远市"&&time=="日报"){//清远市
		message =[{"RANKING":1,"city":"清远市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="清远市"&&time=="周报"){
		message =[{"RANKING":1,"city":"清远市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="清远市"&&time=="月报"){
		message =[{"RANKING":1,"city":"清远市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="云浮市"&&time=="日报"){//云浮市
		message =[{"RANKING":1,"city":"云浮市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="云浮市"&&time=="周报"){
		message =[{"RANKING":1,"city":"云浮市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="云浮市"&&time=="月报"){
		message =[{"RANKING":1,"city":"云浮市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="梅州市"&&time=="日报"){//梅州市
		message =[{"RANKING":1,"city":"梅州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="梅州市"&&time=="周报"){
		message =[{"RANKING":1,"city":"梅州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="梅州市"&&time=="月报"){
		message =[{"RANKING":1,"city":"梅州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="河源市"&&time=="日报"){//河源市
		message =[{"RANKING":1,"city":"河源市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="河源市"&&time=="周报"){
		message =[{"RANKING":1,"city":"河源市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="河源市"&&time=="月报"){
		message =[{"RANKING":1,"city":"河源市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="惠州市"&&time=="日报"){//惠州市
		message =[{"RANKING":1,"city":"惠州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="惠州市"&&time=="周报"){
		message =[{"RANKING":1,"city":"惠州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="惠州市"&&time=="月报"){
		message =[{"RANKING":1,"city":"惠州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="肇庆市"&&time=="日报"){//肇庆市
		message =[{"RANKING":1,"city":"肇庆市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="肇庆市"&&time=="周报"){
		message =[{"RANKING":1,"city":"肇庆市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="肇庆市"&&time=="月报"){
		message =[{"RANKING":1,"city":"肇庆市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="江门市"&&time=="日报"){//江门市
		message =[{"RANKING":1,"city":"江门市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="江门市"&&time=="周报"){
		message =[{"RANKING":1,"city":"江门市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="江门市"&&time=="月报"){
		message =[{"RANKING":1,"city":"江门市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	
	if(city=="东莞市"&&time=="日报"){//东莞市
		message =[{"RANKING":1,"city":"东莞市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="东莞市"&&time=="周报"){
		message =[{"RANKING":1,"city":"东莞市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="东莞市"&&time=="月报"){
		message =[{"RANKING":1,"city":"东莞市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="潮州市"&&time=="日报"){//潮州市
		message =[{"RANKING":1,"city":"潮州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="潮州市"&&time=="周报"){
		message =[{"RANKING":1,"city":"潮州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="潮州市"&&time=="月报"){
		message =[{"RANKING":1,"city":"潮州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	
	
	
}
function comprehensive_Rank(message){
	var tab = $("#report_cycle table");
	$("#report_cycle table tr:gt(0)").remove();
	//开始在table下面追加节点 {"RANKING":1,"city":"广州","IDC_COUNT":25,"IDC_ROOM":84,"IDC_RECORD":121525}
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<tr><td>"+message[i].RANKING+"</td><td>"+message[i].city+"</td><td>"+message[i].IDC_COUNT+"</td><td>"+message[i].IDC_ROOM+"</td><td><a href='javascript:void(0);'>下载</a></td></tr>");
		$(tab).append($(tdhtml));
	}
	$("#echarts_table table tr:odd").css("background","gray");
};



function autoScroll(obj){  
	$(obj).find("ul").animate({  
		marginTop : "-39px"  
	},500,function(){  
		$(this).css({marginTop : "0px"}).find("li:first").appendTo(this);  
	})  
}  





