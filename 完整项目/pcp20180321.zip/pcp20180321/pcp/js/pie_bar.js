function pie_bar(id,data,barName){
    function sortRule(a,b){
        return b.value-a.value;
    }
    var chart=echarts.init(document.getElementById(id));
    

    var data1 = [];
    var pie=[];
    for(var i=0;i<data.length;i++){
        pie[i]=data[i].data;
    }
    for(var i=0;i<pie.length;i++)pie[i].sort(sortRule);
      
    
    for(var i=0;i<pie.length;i++){
        var sum=0;
        for(var j=0;j<pie[i].length;j++){
            sum+=pie[i][j].value;
        }
        data1.push({
            name:data[i].name,
            value:sum,
            type:i
        });
    }

   var data2=[];
   for(var i=0;i<data.length;i++){
        var otherSum=0;
        var other={name:'其它',value:0};
        for(var j=0;j<pie[i].length;j++){
            if(j>=5){
                otherSum+=pie[i][j].value;
                other.value=otherSum;
            }
            else {

                data2.push({
                name:pie[i][j].name,
                value:pie[i][j].value,
                type:i
                });
            }   
        }
        data2.push(other);   
    }

    // console.log(data1[0].name+":"+data1[0].value);
    // console.log(data2[0].name+":"+data2[0].value);



    
    var Top10=data[0].data;
    //alert(data[1].data.length);
    for(var i=1;i<data.length;i++){
        for(var k=0;k<data[i].data.length;k++){
            var tag=0;
            for(var j=0;j<Top10.length;j++){
               
                if(Top10[j].name==(data[i].data[k].name)){
                       
                        Top10[j].value+=data[i].data[k].value;
                        tag=1;
                }
                 
            }
            if(tag==0){
                Top10.push({
                    name:data[i].data[k].name,
                    value:data[i].data[k].value
                })
            }
        }
    }
    
    Top10.sort(sortRule);
    
   
    var top10=[];
    for(var i=0;i<10;i++){
        top10.unshift(Top10[i]);
    }
    var name=top10.map(name=>name.name);
    // alert(top10[0].value)
    option = {
        title:{
             text: barName,
        textStyle: {
            color: "#000",
            fontWeight: "bold",
            fontSize: 14
        },
        top: "50%",
        left: "69%"
        },
        tooltip: {
            
            trigger: 'item',
            formatter: "{b}: {c} ({d}%)",
        },
        grid: [{
            left: "70%",
            right: "20",
            bottom: "10",
            top:'55%',
        
            containLabel: true
        },//pie
        ],
        yAxis: [{
            type: "category",
            
            axisLine: {
                show: false
            },
            axisTick: {
                show: false,
                alignWithLabel: true
            },
            axisLabel: {
                textStyle: {
                    color: "#f00"
                }
            },
            data:name
        }],
        xAxis: [{
            type: "value",
            axisLine: {
                show: false
            },
            axisTick: {
                show: false
            },
            axisLabel: {
                show: false
            },
            splitLine: {
                show: false
            }
        }],
        series: [{

            name: name,
            type: 'pie',
            selectedMode: 'single',
            center: ['35%', '50%'],
            radius: [0, '20%'],

        },{
            name: name,
            type: 'pie',
            selectedMode: 'single',
            hoverAnimation:false,
            center: ['35%', '50%'],
            radius: ['20%', '70%'],
            itemStyle : {
                normal:{color:function(params){
                    if(data.length==1){
                        return 'rgb(0,90,157)';
                    }
                    if(data.length==2){
                        if (params.data.type === 0) {
                         return 'rgb(47,69,84)';
                        }
                        else if (params.data.type === 1) {
                            return 'rgb(183,54,50)';
                        }
                    };
                    if(data.length==3){
                        if (params.data.type === 0) {
                         return 'rgb(47,69,84)';
                        }

                        else if (params.data.type === 1) {
                            return 'rgb(100,60,70)';
                        }
                        else if(params.data.type === 2){
                            return 'rgb(183,54,50)';

                        }
                    }
                    if(data.length==4){
                        if (params.data.type === 0) {
                         return 'rgb(47,69,84)';
                        }

                        else if (params.data.type === 1) {
                            return 'rgb(100,60,70)';
                        }
                        else if(params.data.type === 2){
                            return 'rgb(120,58,60)';
                        }

                        else if(params.data.type === 3){
                            return 'rgb(183,54,50)';

                        }
                    }
                    if(data.length==5){
                        if (params.data.type === 0) {
                         return 'rgb(47,69,84)';
                        }

                        else if (params.data.type === 1) {
                            return 'rgb(65,67,79)';
                        }
                        else if(params.data.type === 2){
                            return 'rgb(84,65,74)';
                        }
                        
                        else if(params.data.type === 3){
                            return 'rgb(140,57,60)';
                        }
                        

                        else if(params.data.type === 4){
                            return 'rgb(183,54,50)';

                        }
                    }
                    if(data.length==6){
                        if (params.data.type === 0) {
                         return 'rgb(47,69,84)';
                        }

                        else if (params.data.type === 1) {
                            return 'rgb(65,67,79)';
                        }
                        else if(params.data.type === 2){
                            return 'rgb(84,65,74)';
                        }
                        else if(params.data.type === 3){
                            return 'rgb(100,60,60)';
                        }
                        else if(params.data.type === 4){
                            return 'rgb(140,57,60)';
                        }
                        

                        else if(params.data.type === 5){
                            return 'rgb(183,54,50)';

                        }
                    }
                    if(data.length==7){
                        if (params.data.type === 0) {
                         return 'rgb(47,69,84)';
                        }

                        else if (params.data.type === 1) {
                            return 'rgb(65,67,79)';
                        }
                        else if(params.data.type === 2){
                            return 'rgb(84,65,74)';
                        }
                        else if(params.data.type === 3){
                            return 'rgb(100,60,60)';
                        }
                        else if(params.data.type === 4){
                            return 'rgb(120,58,60)';
                        }
                        else if(params.data.type === 5){
                            return 'rgb(140,56,55)';
                        }

                        else if(params.data.type === 6){
                            return 'rgb(183,54,50)';

                        }
                    }

                },
            },

            },
            label: {
                normal: {
                    position: 'inside',
                    show: true,
                }
            },
            labelLine: {
                normal: {
                    show: true,
                    length: 20,
                    length2: 25,
                }
            },

            data: data1,
             zlevel: 1
// color: ['#61a0a8', '#2f4554', '#c23521']
            },//Inner_pie 
            {
            name: 'pie',
            type: 'pie',
            hoverAnimation:false,
            center: ['35%', '50%'],
            radius: ['75%', '80%'],
            label: {
                normal: {
                    show: true,
                }
            },
            labelLine: {

            },
            itemStyle: {
                normal: {
                    color: 
                   
                    function(params) 
                    {
                    	if(data.length==1){
                            return 'rgb(0,90,157)';
                        }
                        if(data.length==2){
                            if (params.data.type === 0) {
                             return 'rgb(47,69,84)';
                            }
                            else if (params.data.type === 1) {
                                return 'rgb(183,54,50)';
                            }
                        };
                        if(data.length==3){
                            if (params.data.type === 0) {
                             return 'rgb(47,69,84)';
                            }

                            else if (params.data.type === 1) {
                                return 'rgb(100,60,70)';
                            }
                            else if(params.data.type === 2){
                                return 'rgb(183,54,50)';

                            }
                        }
                        if(data.length==4){
                            if (params.data.type === 0) {
                             return 'rgb(47,69,84)';
                            }

                            else if (params.data.type === 1) {
                                return 'rgb(100,60,70)';
                            }
                            else if(params.data.type === 2){
                                return 'rgb(120,58,60)';
                            }

                            else if(params.data.type === 3){
                                return 'rgb(183,54,50)';

                            }
                        }
                        if(data.length==5){
                            if (params.data.type === 0) {
                             return 'rgb(47,69,84)';
                            }

                            else if (params.data.type === 1) {
                                return 'rgb(65,67,79)';
                            }
                            else if(params.data.type === 2){
                                return 'rgb(84,65,74)';
                            }
                            
                            else if(params.data.type === 3){
                                return 'rgb(140,57,60)';
                            }
                            

                            else if(params.data.type === 4){
                                return 'rgb(183,54,50)';

                            }
                        }
                        if(data.length==6){
                            if (params.data.type === 0) {
                             return 'rgb(47,69,84)';
                            }

                            else if (params.data.type === 1) {
                                return 'rgb(65,67,79)';
                            }
                            else if(params.data.type === 2){
                                return 'rgb(84,65,74)';
                            }
                            else if(params.data.type === 3){
                                return 'rgb(100,60,60)';
                            }
                            else if(params.data.type === 4){
                                return 'rgb(140,57,60)';
                            }
                            

                            else if(params.data.type === 5){
                                return 'rgb(183,54,50)';

                            }
                        }
                        if(data.length==7){
                            if (params.data.type === 0) {
                             return 'rgb(47,69,84)';
                            }

                            else if (params.data.type === 1) {
                                return 'rgb(65,67,79)';
                            }
                            else if(params.data.type === 2){
                                return 'rgb(84,65,74)';
                            }
                            else if(params.data.type === 3){
                                return 'rgb(100,60,60)';
                            }
                            else if(params.data.type === 4){
                                return 'rgb(120,58,60)';
                            }
                            else if(params.data.type === 5){
                                return 'rgb(140,56,55)';
                            }

                            else if(params.data.type === 6){
                                return 'rgb(183,54,50)';

                            }
                        }

                },
                    borderColor: '#ddd',
                    borderWidth: 1,
                }
            },
            data: data2,
             zlevel: 1
        },//Outer_pie
        {
            name: "",
            type: "bar",
            data: top10,
            zlevel: 2,
            barWidth:7,
            barCategoryGap: "50%",
            label: {
                normal: {
                    left:'right',
                    show: true,
                    position: "right",
                    formatter: function(params) {
                        return params.data.value;
                    },
                    textStyle: {
                color: "#000" //color of value
                    }
                }
            },
            itemStyle: {
                normal: {
                    color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
                        offset: 0,
                        color: "rgb(57,67,81)" // 0% 处的颜色
                    }, {
                        offset: 1,
                        color: "rgb(183,54,50)" // 100% 处的颜色
                    }], false),
                    barBorderRadius: [30, 30,30, 30],
                }
            }
        }//bar_top10
        
        ]
    };

    chart.clear();
    chart.setOption(option);
}
    
