var city="全部";
var time="日报";
var message ="";
var num = 0;
var data=[{name:'涉黄',data:[
    {name: '珠海市',value:54},
    {name: '广州市',value: 57},
    {name: '中山市',value:45},
    {name: '佛山市',value: 20},
    {name: '清远市',value:12},
    {name: '梅州市',value: 88},
    {name: '汕头市',value:56},
    {name: '东莞市',value: 10},
    {name: '惠州市',value:31},
    {name: '湛江市',value: 56},
    {name: '深圳市',value: 87}
]},{name:'涉赌',data:[
    {name: '珠海市',value:4},
    {name: '广州市',value: 5},
    {name: '中山市',value:1},
    {name: '佛山市',value: 45},
    {name: '清远市',value:78},
    {name: '梅州市',value: 14},
    {name: '汕头市',value:35},
    {name: '东莞市',value: 48},
    {name: '惠州市',value:12},
    {name: '湛江市',value: 54},
    {name: '深圳市',value: 18},
    {name: '汕尾市',value: 7}
    ]
},{name:'涉毒',data:[
    {name: '珠海市',value:54},
    {name: '广州市',value: 57},
    {name: '中山市',value:45},
    {name: '佛山市',value: 20},
    {name: '清远市',value:12},
    {name: '梅州市',value: 88},
    {name: '汕头市',value:56},
    {name: '东莞市',value: 10},
    {name: '惠州市',value:31},
    {name: '湛江市',value: 56},
    {name: '深圳市',value: 87}
]},{name:'涉政',data:[
    {name: '珠海市',value:4},
    {name: '广州市',value: 5},
    {name: '中山市',value:1},
    {name: '佛山市',value: 45},
    {name: '清远市',value:78},
    {name: '梅州市',value: 14},
    {name: '汕头市',value:35},
    {name: '东莞市',value: 48},
    {name: '惠州市',value:12},
    {name: '湛江市',value: 54},
    {name: '深圳市',value: 18},
    {name: '汕尾市',value: 7}
    ]},{name:'涉稳',data:[
    {name: '珠海市',value:54},
    {name: '广州市',value: 57},
    {name: '中山市',value:45},
    {name: '佛山市',value: 20},
    {name: '清远市',value:12},
    {name: '梅州市',value: 88},
    {name: '汕头市',value:56},
    {name: '东莞市',value: 10},
    {name: '惠州市',value:31},
    {name: '湛江市',value: 56},
    {name: '深圳市',value: 87}
]},{name:'涉恐',data:[
    {name: '珠海市',value:4},
    {name: '广州市',value: 5},
    {name: '中山市',value:1},
    {name: '佛山市',value: 45},
    {name: '清远市',value:78},
    {name: '梅州市',value: 14},
    {name: '汕头市',value:35},
    {name: '东莞市',value: 48},
    {name: '惠州市',value:12},
    {name: '湛江市',value: 54},
    {name: '深圳市',value: 18},
    {name: '汕尾市',value: 7}
    ]},{name:'翻墙代理',data:[
    {name: '珠海市',value:4},
    {name: '广州市',value: 5},
    {name: '中山市',value:1},
    {name: '佛山市',value: 45},
    {name: '清远市',value:78},
    {name: '梅州市',value: 14},
    {name: '汕头市',value:35},
    {name: '东莞市',value: 48},
    {name: '惠州市',value:12},
    {name: '湛江市',value: 54},
    {name: '深圳市',value: 18},
    {name: '汕尾市',value: 7}
    ]}];
var rawData = [
    {name: '珠海市',value:130},
    {name: '广州市',value: 120},
    {name: '中山市',value:110},
    {name: '佛山市',value: 100},
    {name: '清远市',value:90},
    {name: '梅州市',value: 70},
    {name: '汕头市',value:80},
    {name: '东莞市',value: 30},
    {name: '惠州市',value:50},
    {name: '湛江市',value: 40},
    {name: '深圳市',value: 60}
    ];

var arr=[{name:'1号',value:30},{name:'2号',value:20},{name:'3号',value:10},{name:'4号',value:50}];
var pre=[100.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3],
now=[2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8];
$(function(){
	/*
	 * 地图加载
	 * rawData  地图上的标注
	 * rawData  top10
	 * */
	Map('map_province',rawData,rawData);
	//定时轮播table数据
	setInterval('autoScroll(".maquee")',3000);
	setInterval('autoScroll(".maquee2")',3000);
	//加载柱状图
	Map_safeTrend('content',pre,now);
	//默认加载信息安全事件
	pie_bar('wxts_echarts',data,'信息安全事件Top10');
	//全省IDC威胁态势的点击事件
	typechoose();
	//默认加载全部城市的日报
	loadtables(city,time);
	//选择日报周报月报事件
	choosetime();
	//选择城市事件
	choosecity();
});
//地图下面的点击事件切换
$(".addorless").click(function(){
	if(num==0){
		$("#map_province").css("display","none");
		$("#curve_province").css("display","block");
		line('curve_province',arr,'全省IDC安全态势');
		num=num+1;
		$(this).html("<");
	}else{
		$("#map_province").css("display","block");
		$("#curve_province").css("display","none");
		Map('map_province',rawData,rawData);
		num=num-1;
		$(this).html(">");
	}
});

//IDC安全报告的城市点击事件
function choosecity(){
	var obj_lis = document.getElementById("report_city").getElementsByTagName("td");
    for(i=0;i<obj_lis.length;i++){
        obj_lis[i].onclick = function(){
        	city = this.innerHTML;
        	$(obj_lis).css("background-color","");
            $(this).css("background-color","rgb(0,72,128)");
            //加载table 数据
        	loadtables(city,time);
        }
    }
}
//IDC安全报告的时间点击事件
function choosetime(){
	var obj_lis = document.getElementById("report_cycle").getElementsByTagName("li");
    for(i=0;i<obj_lis.length;i++){
        obj_lis[i].onclick = function(){
            time = this.innerHTML;
            $(this).css("border-bottom","2px solid rgb(0,90,160)");
            $(this).siblings().css("border-bottom","");
            //加载table 数据
        	loadtables(city,time);
        }
    }
}
//全省IDC威胁态势的点击事件
function typechoose(){
	var obj_lis = document.getElementById("wxts_choose").getElementsByTagName("li");
    for(i=0;i<obj_lis.length;i++){
        obj_lis[i].onclick = function(){
            var type = this.innerHTML;
            $(this).css("background-color","rgb(74,144,226)");
            $(this).siblings().css("background-color","");
            //加载echarts
        	if(type=="信息安全事件"){
        		data=[{name:'涉黄',data:[
        		    {name: '珠海市',value:54},
        		    {name: '广州市',value: 57},
        		    {name: '中山市',value:45},
        		    {name: '佛山市',value: 20},
        		    {name: '清远市',value:12},
        		    {name: '梅州市',value: 88},
        		    {name: '汕头市',value:56},
        		    {name: '东莞市',value: 10},
        		    {name: '惠州市',value:31},
        		    {name: '湛江市',value: 56},
        		    {name: '深圳市',value: 87}
        		]
        		},
        		{name:'涉赌',data:[
        		    {name: '珠海市',value:4},
        		    {name: '广州市',value: 5},
        		    {name: '中山市',value:1},
        		    {name: '佛山市',value: 45},
        		    {name: '清远市',value:78},
        		    {name: '梅州市',value: 14},
        		    {name: '汕头市',value:35},
        		    {name: '东莞市',value: 48},
        		    {name: '惠州市',value:12},
        		    {name: '湛江市',value: 54},
        		    {name: '深圳市',value: 18},
        		    {name: '汕尾市',value: 7}
        		    ]
        		},
        		{name:'涉毒',data:[
        		    {name: '珠海市',value:54},
        		    {name: '广州市',value: 57},
        		    {name: '中山市',value:45},
        		    {name: '佛山市',value: 20},
        		    {name: '清远市',value:12},
        		    {name: '梅州市',value: 88},
        		    {name: '汕头市',value:56},
        		    {name: '东莞市',value: 10},
        		    {name: '惠州市',value:31},
        		    {name: '湛江市',value: 56},
        		    {name: '深圳市',value: 87}
        		]
        		},
        		{name:'涉政',data:[
        		    {name: '珠海市',value:4},
        		    {name: '广州市',value: 5},
        		    {name: '中山市',value:1},
        		    {name: '佛山市',value: 45},
        		    {name: '清远市',value:78},
        		    {name: '梅州市',value: 14},
        		    {name: '汕头市',value:35},
        		    {name: '东莞市',value: 48},
        		    {name: '惠州市',value:12},
        		    {name: '湛江市',value: 54},
        		    {name: '深圳市',value: 18},
        		    {name: '汕尾市',value: 7}
        		    ]
        		},{name:'涉稳',data:[
        		    {name: '珠海市',value:54},
        		    {name: '广州市',value: 57},
        		    {name: '中山市',value:45},
        		    {name: '佛山市',value: 20},
        		    {name: '清远市',value:12},
        		    {name: '梅州市',value: 88},
        		    {name: '汕头市',value:56},
        		    {name: '东莞市',value: 10},
        		    {name: '惠州市',value:31},
        		    {name: '湛江市',value: 56},
        		    {name: '深圳市',value: 87}
        		]
        		},
        		{name:'涉恐',data:[
        		    {name: '珠海市',value:4},
        		    {name: '广州市',value: 5},
        		    {name: '中山市',value:1},
        		    {name: '佛山市',value: 45},
        		    {name: '清远市',value:78},
        		    {name: '梅州市',value: 14},
        		    {name: '汕头市',value:35},
        		    {name: '东莞市',value: 48},
        		    {name: '惠州市',value:12},
        		    {name: '湛江市',value: 54},
        		    {name: '深圳市',value: 18},
        		    {name: '汕尾市',value: 7}
        		    ]
        		},
        		{name:'翻墙代理',data:[
        		    {name: '珠海市',value:4},
        		    {name: '广州市',value: 5},
        		    {name: '中山市',value:1},
        		    {name: '佛山市',value: 45},
        		    {name: '清远市',value:78},
        		    {name: '梅州市',value: 14},
        		    {name: '汕头市',value:35},
        		    {name: '东莞市',value: 48},
        		    {name: '惠州市',value:12},
        		    {name: '湛江市',value: 54},
        		    {name: '深圳市',value: 18},
        		    {name: '汕尾市',value: 7}
        		    ]
        		}
        		];
        		pie_bar('wxts_echarts',data,'信息安全事件Top10');
        	}
        	if(type=="网络安全事件"){
        		data = [ {
    				name : '遭受入侵',
    				data : [ {
    					name : '珠海市',
    					value : 130
    				}, {
    					name : '广州市',
    					value : 50
    				}, {
    					name : '中山市',
    					value : 30
    				}, {
    					name : '佛山市',
    					value : 50
    				}, {
    					name : '清远市',
    					value : 30
    				}, {
    					name : '梅州市',
    					value : 50
    				}, {
    					name : '汕头市',
    					value : 30
    				}, {
    					name : '东莞市',
    					value : 50
    				}, {
    					name : '惠州市',
    					value : 30
    				}, {
    					name : '湛江市',
    					value : 50
    				}, {
    					name : '深圳市',
    					value : 50
    				} ]
    			}, {
    				name : '黑客控制',
    				data : [ {
    					name : '珠海市',
    					value : 130
    				}, {
    					name : '广州市',
    					value : 100
    				}, {
    					name : '中山市',
    					value : 30
    				}, {
    					name : '佛山市',
    					value : 50
    				}, {
    					name : '清远市',
    					value : 30
    				}, {
    					name : '梅州市',
    					value : 50
    				}, {
    					name : '汕头市',
    					value : 30
    				}, {
    					name : '东莞市',
    					value : 50
    				}, {
    					name : '惠州市',
    					value : 30
    				}, {
    					name : '湛江市',
    					value : 50
    				}, {
    					name : '深圳市',
    					value : 50
    				}, {
    					name : '汕尾市',
    					value : 50
    				} ]
    			}, {
    				name : '黑客牟利',
    				data : [ {
    					name : '珠海市',
    					value : 130
    				}, {
    					name : '广州市',
    					value : 100
    				}, {
    					name : '中山市',
    					value : 30
    				}, {
    					name : '佛山市',
    					value : 50
    				}, {
    					name : '清远市',
    					value : 30
    				}, {
    					name : '梅州市',
    					value : 50
    				}, {
    					name : '汕头市',
    					value : 30
    				}, {
    					name : '东莞市',
    					value : 50
    				}, {
    					name : '惠州市',
    					value : 30
    				}, {
    					name : '湛江市',
    					value : 50
    				}, {
    					name : '深圳市',
    					value : 50
    				}, {
    					name : '汕尾市',
    					value : 50
    				} ]
    			} , {
    				name : '内部攻击',
    				data : [ {
    					name : '珠海市',
    					value : 130
    				}, {
    					name : '广州市',
    					value : 100
    				}, {
    					name : '中山市',
    					value : 30
    				}, {
    					name : '佛山市',
    					value : 50
    				}, {
    					name : '清远市',
    					value : 30
    				}, {
    					name : '梅州市',
    					value : 50
    				}, {
    					name : '汕头市',
    					value : 30
    				}, {
    					name : '东莞市',
    					value : 50
    				}, {
    					name : '惠州市',
    					value : 30
    				}, {
    					name : '湛江市',
    					value : 50
    				}, {
    					name : '深圳市',
    					value : 50
    				}, {
    					name : '汕尾市',
    					value : 50
    				} ]
    			}];
        		pie_bar('wxts_echarts',data,'网络安全事件Top10');
        	}
        	if(type=="未备案事件"){
        		data = [ {
    				name : '备案',
    				data : [ {
    					name : '珠海市',
    					value : 130
    				}, {
    					name : '广州市',
    					value : 50
    				}, {
    					name : '中山市',
    					value : 30
    				}, {
    					name : '佛山市',
    					value : 50
    				}, {
    					name : '清远市',
    					value : 30
    				}, {
    					name : '梅州市',
    					value : 50
    				}, {
    					name : '汕头市',
    					value : 30
    				}, {
    					name : '东莞市',
    					value : 50
    				}, {
    					name : '惠州市',
    					value : 30
    				}, {
    					name : '湛江市',
    					value : 50
    				}, {
    					name : '深圳市',
    					value : 50
    				} ]
    			}, {
    				name : '未备案',
    				data : [ {
    					name : '珠海市',
    					value : 130
    				}, {
    					name : '广州市',
    					value : 100
    				}, {
    					name : '中山市',
    					value : 30
    				}, {
    					name : '佛山市',
    					value : 50
    				}, {
    					name : '清远市',
    					value : 30
    				}, {
    					name : '梅州市',
    					value : 50
    				}, {
    					name : '汕头市',
    					value : 30
    				}, {
    					name : '东莞市',
    					value : 50
    				}, {
    					name : '惠州市',
    					value : 30
    				}, {
    					name : '湛江市',
    					value : 50
    				}, {
    					name : '深圳市',
    					value : 50
    				}, {
    					name : '汕尾市',
    					value : 50
    				} ]
    			} ];
        		pie_bar('wxts_echarts',data,'未备案事件Top10');
        	}
        }
    }
}

function loadtables(city,time){
	if(city=="全部"&&time=="日报"){
		message =[{"RANKING":1,"city":"广州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"},{"RANKING":2,"city":"珠海市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"},{"RANKING":3,"city":"深圳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="全部"&&time=="周报"){
		message =[{"RANKING":1,"city":"广州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"},{"RANKING":2,"city":"珠海市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="全部"&&time=="月报"){
		message =[{"RANKING":1,"city":"佛山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"},{"RANKING":2,"city":"惠州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="广州市"&&time=="日报"){//广州
		message =[{"RANKING":1,"city":"广州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="广州市"&&time=="周报"){
		message =[{"RANKING":1,"city":"广州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="广州市"&&time=="月报"){
		message =[{"RANKING":1,"city":"广州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="深圳市"&&time=="日报"){//深圳市
		message =[{"RANKING":1,"city":"深圳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="深圳市"&&time=="周报"){
		message =[{"RANKING":1,"city":"深圳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="深圳市"&&time=="月报"){
		message =[{"RANKING":1,"city":"深圳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="珠海市"&&time=="日报"){//珠海市
		message =[{"RANKING":1,"city":"珠海市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="珠海市"&&time=="周报"){
		message =[{"RANKING":1,"city":"珠海市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="珠海市"&&time=="月报"){
		message =[{"RANKING":1,"city":"珠海市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="揭阳市"&&time=="日报"){//揭阳市
		message =[{"RANKING":1,"city":"揭阳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="揭阳市"&&time=="周报"){
		message =[{"RANKING":1,"city":"揭阳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="揭阳市"&&time=="月报"){
		message =[{"RANKING":1,"city":"揭阳市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="汕尾市"&&time=="日报"){//汕尾市
		message =[{"RANKING":1,"city":"汕尾市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="汕尾市"&&time=="周报"){//
		message =[{"RANKING":1,"city":"汕尾市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="汕尾市"&&time=="月报"){
		message =[{"RANKING":1,"city":"汕尾市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="汕头市"&&time=="日报"){//汕头市
		message =[{"RANKING":1,"city":"汕头市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="汕头市"&&time=="周报"){
		message =[{"RANKING":1,"city":"汕头市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="汕头市"&&time=="月报"){
		message =[{"RANKING":1,"city":"汕头市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="佛山市"&&time=="日报"){//佛山市
		message =[{"RANKING":1,"city":"佛山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="佛山市"&&time=="周报"){
		message =[{"RANKING":1,"city":"佛山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="佛山市"&&time=="月报"){
		message =[{"RANKING":1,"city":"佛山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="中山市"&&time=="日报"){//中山市
		message =[{"RANKING":1,"city":"中山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="中山市"&&time=="周报"){
		message =[{"RANKING":1,"city":"中山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="中山市"&&time=="月报"){
		message =[{"RANKING":1,"city":"中山市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="湛江市"&&time=="日报"){//湛江市
		message =[{"RANKING":1,"city":"湛江市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="湛江市"&&time=="周报"){
		message =[{"RANKING":1,"city":"湛江市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="湛江市"&&time=="月报"){
		message =[{"RANKING":1,"city":"湛江市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="阳江市"&&time=="日报"){//阳江市
		message =[{"RANKING":1,"city":"阳江市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="阳江市"&&time=="周报"){
		message =[{"RANKING":1,"city":"阳江市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="阳江市"&&time=="月报"){
		message =[{"RANKING":1,"city":"阳江市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="茂名市"&&time=="日报"){//茂名市
		message =[{"RANKING":1,"city":"茂名市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="茂名市"&&time=="周报"){
		message =[{"RANKING":1,"city":"茂名市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="茂名市"&&time=="月报"){
		message =[{"RANKING":1,"city":"茂名市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="韶关市"&&time=="日报"){//韶关市
		message =[{"RANKING":1,"city":"韶关市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="韶关市"&&time=="周报"){
		message =[{"RANKING":1,"city":"韶关市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="韶关市"&&time=="月报"){
		message =[{"RANKING":1,"city":"韶关市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="清远市"&&time=="日报"){//清远市
		message =[{"RANKING":1,"city":"清远市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="清远市"&&time=="周报"){
		message =[{"RANKING":1,"city":"清远市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="清远市"&&time=="月报"){
		message =[{"RANKING":1,"city":"清远市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="云浮市"&&time=="日报"){//云浮市
		message =[{"RANKING":1,"city":"云浮市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="云浮市"&&time=="周报"){
		message =[{"RANKING":1,"city":"云浮市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="云浮市"&&time=="月报"){
		message =[{"RANKING":1,"city":"云浮市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="梅州市"&&time=="日报"){//梅州市
		message =[{"RANKING":1,"city":"梅州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="梅州市"&&time=="周报"){
		message =[{"RANKING":1,"city":"梅州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="梅州市"&&time=="月报"){
		message =[{"RANKING":1,"city":"梅州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="河源市"&&time=="日报"){//河源市
		message =[{"RANKING":1,"city":"河源市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="河源市"&&time=="周报"){
		message =[{"RANKING":1,"city":"河源市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="河源市"&&time=="月报"){
		message =[{"RANKING":1,"city":"河源市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="惠州市"&&time=="日报"){//惠州市
		message =[{"RANKING":1,"city":"惠州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="惠州市"&&time=="周报"){
		message =[{"RANKING":1,"city":"惠州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="惠州市"&&time=="月报"){
		message =[{"RANKING":1,"city":"惠州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="肇庆市"&&time=="日报"){//肇庆市
		message =[{"RANKING":1,"city":"肇庆市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="肇庆市"&&time=="周报"){
		message =[{"RANKING":1,"city":"肇庆市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="肇庆市"&&time=="月报"){
		message =[{"RANKING":1,"city":"肇庆市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="江门市"&&time=="日报"){//江门市
		message =[{"RANKING":1,"city":"江门市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="江门市"&&time=="周报"){
		message =[{"RANKING":1,"city":"江门市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="江门市"&&time=="月报"){
		message =[{"RANKING":1,"city":"江门市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	
	if(city=="东莞市"&&time=="日报"){//东莞市
		message =[{"RANKING":1,"city":"东莞市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="东莞市"&&time=="周报"){
		message =[{"RANKING":1,"city":"东莞市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="东莞市"&&time=="月报"){
		message =[{"RANKING":1,"city":"东莞市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="潮州市"&&time=="日报"){//潮州市
		message =[{"RANKING":1,"city":"潮州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180313至20180313"}];
		comprehensive_Rank(message);
	}
	if(city=="潮州市"&&time=="周报"){
		message =[{"RANKING":1,"city":"潮州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180305至20180311"}];
		comprehensive_Rank(message);
	}
	if(city=="潮州市"&&time=="月报"){
		message =[{"RANKING":1,"city":"潮州市IDC安全报告20180312-综合安全报告","IDC_COUNT":"第001期","IDC_ROOM":"20180301至20180311"}];
		comprehensive_Rank(message);
	}
	
	
	
}
function comprehensive_Rank(message){
	var tab = $("#report_cycle table");
	$("#report_cycle table tr:gt(0)").remove();
	//开始在table下面追加节点 {"RANKING":1,"city":"广州","IDC_COUNT":25,"IDC_ROOM":84,"IDC_RECORD":121525}
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<tr><td>"+message[i].RANKING+"</td><td>"+message[i].city+"</td><td>"+message[i].IDC_COUNT+"</td><td>"+message[i].IDC_ROOM+"</td><td><a href='javascript:void(0);'>下载</a></td></tr>");
		$(tab).append($(tdhtml));
	}
	$("#echarts_table table tr:odd").css("background","gray");
};



function autoScroll(obj){  
	$(obj).find("ul").animate({  
		marginTop : "-39px"  
	},500,function(){  
		$(this).css({marginTop : "0px"}).find("li:first").appendTo(this);  
	})  
}  
