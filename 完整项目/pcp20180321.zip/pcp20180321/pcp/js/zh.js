var message_xxaq=[];
var message_zzfd=[];
var message_bkxx=[];
var message_zgcl=[];
var message_ywgtyhf=[];
var message_ycll=[];
var message_fxfwq=[];




function errorFunc(){
	alert('Error:\n数据读取失败');
}
function City(url1,url2,url3,url4,url5){
	url1='http://172.18.2.61/SMMS/SMMS/SmmsEventMainBiz/getIdcEventJson';
	url2='http://172.18.2.61/SMMS/SMMS/SmmsCitySumYbBiz/getSmmsCitySumYbJson';
	url3='http://172.18.2.61/SMMS/SMMS/SmmsEventMainBiz/getShddJson';
	url4='http://172.18.2.61/SMMS/SMMS/SmmsEventMainBiz/getSzwJson';
	url5='http://172.18.2.61/SMMS/SMMS/SmmsEventMainBiz/getSkJson';
	url6='http://172.18.2.61/SMMS/SMMS/SmmsEventMainBiz/getZgClJson';
	url7='http://172.18.2.61/SMMS/SMMS/SmmsEventMainBiz/getGtHfJson';
	url8='http://172.18.2.61/SMMS/SMMS/SmmsEventMainBiz/getYcllJson';
	url9='http://172.18.2.61/SMMS/SMMS/SmmsEventMainBiz/getFxFwqJson';
	url5='http://172.18.2.61/SMMS/SMMS/SmmsEventMainBiz/getSkJson';
	
	
	
	url1='../js/data1.json';
	url2='../js/data2.json';
	url3='../js/data3.json';
	url4='../js/data4.json';
	url5='../js/data5.json';
	url6='../js/data6.json';
	url7='../js/data7.json';
	url8='../js/data8.json';
	url9='../js/data9.json';
	url5='../js/data5.json';
	
	$.ajax({
		type:'GET',
		url:url1,
		dataType:'json',
		success:success1,
		error:errorFunc,
	});
	$.ajax({
		type:'GET',
		url:url2,
		dataType:'json',
		success:success2,
		error:errorFunc,
	});
	$.ajax({
		type:'GET',
		url:url3,
		dataType:'json',
		success:success3,
		error:errorFunc,
	});
	
	$.ajax({
		type:'GET',
		url:url4,
		dataType:'json',
		success:success4,
		error:errorFunc,
	});
	
	$.ajax({
		type:'GET',
		url:url5,
		dataType:'json',
		success:success5,
		error:errorFunc,
	});
	
	$.ajax({//整改处理
		type:'GET',
		url:url6,
		dataType:'json',
		success:success6,
		error:errorFunc,
	});
	
	$.ajax({//业务关停与恢复
		type:'GET',
		url:url7,
		dataType:'json',
		success:success7,
		error:errorFunc,
	});
	
	$.ajax({//异常流量
		type:'GET',
		url:url8,
		dataType:'json',
		success:success8,
		error:errorFunc,
	});
	
	$.ajax({//风险服务器
		type:'GET',
		url:url9,
		dataType:'json',
		success:success9,
		error:errorFunc,
	});
	
	
	function ZHAQSJ_count(SPTPROEVENT){
		var count=SPTPROEVENT.WBA+SPTPROEVENT.SS2+SPTPROEVENT.SS1+SPTPROEVENT.FQDL+
			SPTPROEVENT.ZSRQ+SPTPROEVENT.HKKZ+SPTPROEVENT.HCML+SPTPROEVENT.NBGJ;
		$('#zhaqsjs').text(count);
		//$('#zhaqsjs').text(SPTPROEVENT.ZHAQSJ);
		$('#wba').text(SPTPROEVENT.WBA);
		$('#hdd').text(SPTPROEVENT.SS2);
		$('#zwk').text(SPTPROEVENT.SS1);
		$('#fqdl').text(SPTPROEVENT.FQDL);
		$('#zsrq').text(SPTPROEVENT.ZSRQ);
		$('#hkkz').text(SPTPROEVENT.HKKZ);
		$('#hcml').text(SPTPROEVENT.HCML);
		$('#nbgj').text(SPTPROEVENT.NBGJ);
	};
	function success1(data){//左上角安全态势地图
		var SPTPROEVENT={},SPTCITYEVENTTOP10=[],SPTCITYEVENTALL=[];
		SPTPROEVENT=data.SMMSEVENT;//1.全省IDC安全态势：（八大事件）:SPTPROEVENT：WBA+SS2+SS1+FQDL+ZSRQ+HKKZ+HCML+NBGJ
		SPTCITYEVENTTOP10=data.SMMSIDCEVENTTOP10;//用于综合安全事件影响排名10
		SPTCITYEVENTALL=data.SMMSIDCEVENTTOP10;//用于条形图，显示给个地市的综合安全地市数量
		//console.log(data);
		var cityData=[];
		for(var i=0;i<SPTCITYEVENTALL.length;i++){
			cityData.push({name:SPTCITYEVENTALL[i].IDC_NAME,value:SPTCITYEVENTALL[i].TOTALTOP10});
		}
		console.log(cityData);
		Map_city('map_city',cityData,"珠海市",geoCoordMap,'35%');
		
//		$('#zhexiantu').css('height','10px').css('width','20px');
//		line('zhexiantu',arr,'');
		//地图下面的点击事件切换
		$(".alldata").css('cursor','pointer');
		$(".alldata").click(function(){
			if(num==0){
				$("#map_city").css("display","none");
				$("#curve_city").css("display","block");
				line('curve_city',arr,'珠海市IDC安全态势');
				num=num+1;
				$('.addorless_city').html("<");
			}else{
				$("#map_city").css("display","block");
				$("#curve_city").css("display","none");
				Map_city('map_city',cityData,"珠海市",geoCoordMap,'35%');
				num=num-1;
				$('.addorless_city').html(">");
			}
		});
		
		ZHAQSJ_count(SPTPROEVENT);
//		setInterval('autoScroll(".maquee")',3000);
//		setInterval('autoScroll(".maquee2")',3000);
		
		
	}
	
	
	
	//success2
	function IDCjierutongji(CITY_TOTAL){
		$('#yys').html(CITY_TOTAL.YYSS+'<span>个</span>');
		$('#jf').html(CITY_TOTAL.IDCJFS+'<span>个</span>');
		$('#ybaym').html(CITY_TOTAL.WZBAS+'<span>个</span>');	
	};

	function success2(data){//右上角IDC介入统计
		IDCjierutongji(data[0]);//接入统计
		
		
		
		
		//网络安全事件趋势条形图
		var year=new Date();
		var nowYear= parseInt(year.getFullYear());
		preYear=nowYear-1;
		//alert(preYear)
		
		var predata=[],nowdata=[];
		for(var i=0;i<12;i++){predata[i]=0;nowdata[i]=0;}
		for(var i=0;i<data.length;i++){
			if(data[i].NF==preYear){predata[data[i].YF-1]=data[i].AQSJZS;}
			else if(data[i].NF==nowYear){nowdata[data[i].YF-1]=data[i].AQSJZS;}
		}
		
		Map_safeTrend('aqsjqs_content',preYear+'年',nowYear+'年',predata,nowdata);
	}
	
	function success3(data){//黄赌毒
		message_xxaq=data;
		comprehensive_Rank(message_xxaq,'xingxianquan');
		
	}
	function success4(data){//政治反动
		message_zzfd=data;
		comprehensive_Rank(message_zzfd,'wangluoanquan');
		
	}
	function success5(data){//暴恐信息
		message_bkxx=data;
		comprehensive_Rank(message_bkxx,'weibeian');
	}
	function success6(data){//整改处理
		message_zgcl=data;
		
		comprehensive_Rank1(message_zgcl,'zhenggaichuli');
	}
	
	function success7(data){//业务关停与恢复
		message_ywgtyhf=data;
		
		comprehensive_Rank2(message_ywgtyhf,'yewuhuifuyushouli');
	}
	
	function success8(data){//异常流量
		message_ycll=data;
		
		comprehensive_RankLL(message_ycll,'yichangliulian');
	}
	
	function success9(data){//风险服务器
		message_fxfwq=data;
		
		comprehensive_RankFX(message_fxfwq,'fengxiangfuwuqi');
	}
	
//	$(function(){
//		/*
//		 * 地图加载
//		 * rawData  地图上的标注
//		 * rawData  top10
//		 * */
//		Map('map',rawData,rawData);
//		//定时轮播table数据
////		setInterval('autoScroll(".maquee")',3000);
////		setInterval('autoScroll(".maquee2")',3000);
////		//加载柱状图
////		Map_safeTrend('content',pre,now);
////		//默认加载信息安全事件
////		pie_bar('wxts_echarts',data,'信息安全事件Top10');
////		//全省IDC威胁态势的点击事件
////		typechoose();
////		//默认加载全部城市的日报
////		loadtables(city,time);
////		//选择日报周报月报事件
////		choosetime();
////		//选择城市事件
////		choosecity();
//	});
	
}
City('1','2','3','4','5');



var flag1=1;//未处理
var flag2=1;//已关停
var flag3=1;//已下发

var flag4=1;//未处理
var flag5=1;//已关停
var flag6=1;//已下发

var flag7=1;//未处理
var flag8=1;//已关停
var flag9=1;//已下发

var num = 0;
var rawData_city = [
    {name: '时代互联',value:15},
    {name: '讯天在线',value: 34},
    {name: '盛网软件',value: 25},
    {name: '耐思尼克',value: 46}
    
    ];
var geoCoordMap = {
	    '时代互联':[113.572599,22.271175],
	    '耐思尼克':[113.512233,22.350351],
	    '讯天在线':[113.566275,22.307024],
	    '盛网软件':[113.352981,22.152592]
	    };
var arr=[{name:'1号',value:30},{name:'2号',value:20},{name:'3号',value:10},{name:'4号',value:50}];//曲线数据
var pre=[100.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3];//前一年度数
var now=[2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8];//当前年度数据
var message_aqld=[{"name_ld":"安全漏洞","effect_com":"45","effect_room":"787"}];//安全漏洞

//IDC安全报告
var message_day=[{"title":"珠海市IDC安全报告20180312-综合安全报告","periods":"第001期","range":"2018-03-14"},{"title":"珠海市IDC安全报告20180317-综合安全报告","periods":"第002期","range":"2018-03-14"}];
var message_week=[{"title":"珠海市IDC安全报告20180312-综合安全报告","periods":"第001期","range":"2018-03-14"},{"title":"珠海市IDC安全报告20180317-综合安全报告","periods":"第002期","range":"2018-03-14"},{"title":"珠海市IDC安全报告20180312-综合安全报告","periods":"第001期","range":"2018-03-14"},{"title":"珠海市IDC安全报告20180317-综合安全报告","periods":"第002期","range":"2018-03-14"}];
var message_month=[{"title":"珠海市IDC安全报告20180312-综合安全报告","periods":"第001期","range":"2018-03-14"},{"title":"珠海市IDC安全报告20180317-综合安全报告","periods":"第002期","range":"2018-03-14"},{"title":"珠海市IDC安全报告20180312-综合安全报告","periods":"第001期","range":"2018-03-14"},{"title":"珠海市IDC安全报告20180317-综合安全报告","periods":"第002期","range":"2018-03-14"},{"title":"珠海市IDC安全报告20180312-综合安全报告","periods":"第001期","range":"2018-03-14"},{"title":"珠海市IDC安全报告20180317-综合安全报告","periods":"第002期","range":"2018-03-14"}];
$(function(){
	//Map_city('map_city',rawData_city,"珠海市",geoCoordMap,'35%');
	//加载基础数据
	//showData();
	//加载柱状图
	//load_bar();
	//加载table
	//comprehensive_Rank(message_xxaq,'xingxianquan');
//	comprehensive_Rank(message_zzfd,'wangluoanquan');
//	comprehensive_Rank(message_wba,'weibeian');
//	comprehensive_Rank(message_zgcl,'zhenggaichuli');
//	comprehensive_Rank2(message_ywgtyhf,'yewuhuifuyushouli');
	comprehensive_Rank3(message_aqld,'anquanloudong');
	
	//默认加载日报内容
	comprehensive_Rank5(message_day,'anquanbaogao');
	choosetime();
	//复选框选中事件
	checkType();
});


//开始加载table的排名顺序
function comprehensive_Rank(message,classname){//黄赌毒、政治反动、暴恐信息
	$("#"+classname).empty();
	var tab = $("#"+classname);
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<li><div>"+message[i].IDC_NAME+"</div><div>"+message[i].ROOM_NAME+"</div><div>"+message[i].DOMAIN_NAME+"</div><div>"+message[i].WEBSITE_NAME+"</div><div>"+message[i].RECTIFY_STATE+"</div></li>");
		$(tab).append($(tdhtml));
	}
};
function comprehensive_Rank1(message,classname){//整改处理
	$("#"+classname).empty();
	var tab = $("#"+classname);
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<li><div>"+message[i].IDC_NAME+"</div><div>"+message[i].ROOM_NAME+"</div><div>"+message[i].DZG+"</div><div>"+message[i].ZGZ+"</div><div>"+message[i].YZG+"</div></li>");
		$(tab).append($(tdhtml));
	}
};
//开始加载table的排名顺序
function comprehensive_Rank2(message,classname){
	var tab = $("#"+classname);
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<li><div>"+message[i].IDC_NAME+"</div><div>"+message[i].ROOM_NAME+"</div><div>"+message[i].GTZ+"</div><div>"+message[i].SQHF+"</div><div>"+message[i].YSL+"</div><div>"+message[i].SHZ+"</div><div>"+message[i].YHF+"</div></li>");
		$(tab).append($(tdhtml));
	}
};
//开始加载table的排名顺序
function comprehensive_Rank3(message,classname){
	var tab = $("#"+classname);
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<li><div>"+message[i].name_ld+"</div><div>"+message[i].effect_com+"</div><div>"+message[i].effect_room+"</div></li>");
		$(tab).append($(tdhtml));
	}
};
//开始加载table的排名顺序
function comprehensive_Rank5(message,classname){
	$("#anquanbaogao tr:gt(0)").remove();
	var tab = $("#"+classname);
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<tr><td>"+message[i].title+"</td><td>"+message[i].periods+"</td><td>"+message[i].range+"</td><td><a href=''>下载</a></td></tr>");
		$(tab).append($(tdhtml));
	}
};

function comprehensive_RankLL(message,classname){
	var tab = $("#"+classname);
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<li><div>"+message[i].IDC_NAME+"</div><div>"+message[i].ROOM_NAME+"</div><div>"+message[i].ip+"</div><div>"+message[i].ATTACK_IP+"</div><div>"+message[i].event_type2+"</div></li>");
		$(tab).append($(tdhtml));
	}
};

function comprehensive_RankFX(message,classname){
	var tab = $("#"+classname);
	for (var i = 0; i < message.length; i++) {
		//创建节点
		var tdhtml = $("<li><div>"+message[i].IDC_NAME+"</div><div>"+message[i].ROOM_NAME+"</div><div>"+message[i].IP+"</div><div>"+message[i].RECTIFY_STATE+"</div><div>"+message[i].THREAT_TYPE2+"</div></li>");
		$(tab).append($(tdhtml));
	}
};

//IDC安全报告的时间点击事件
function choosetime(){
	var obj_lis = document.getElementById("report_cycle").getElementsByTagName("li");
    for(i=0;i<obj_lis.length;i++){
        obj_lis[i].onclick = function(){
            var time = this.innerHTML;
            $(this).css("border-bottom","2px solid rgb(0,90,160)");
            $(this).siblings().css("border-bottom","");
            //加载table 数据
            if(time=="日报"){
            	comprehensive_Rank5(message_day,'anquanbaogao')
            }
            if(time=="周报"){
            	comprehensive_Rank5(message_week,'anquanbaogao')
            }
            if(time=="月报"){
            	comprehensive_Rank5(message_month,'anquanbaogao')
            }
        }
    }
}
function checkType(){
	var s = $("input[name='check1']");
    s.each(function(i) {
            $(this).click(function(){
//            	var SelectFalse = true; //用于判断是否被选择条件
            	var arr=[];
                if(this.checked==true){
                      var val = this.value;
                      if(val==0){
                    	  flag1=1;
                      }
                      if(val==1){
                    	  flag2=1;
                      }
                      if(val==2){
                    	  flag3=1;
                      }
                }else{
                	var val = this.value;
                    if(val==0){
                  	  flag1=0;
                    }
                    if(val==1){
                  	  flag2=0;
                    }
                    if(val==2){
                  	  flag3=0;
                    }
                }
                if(flag1==0&&flag2==0&&flag3==0){
                	var val = this.value;
                	if(val==0){
                  	  flag1=1;
                    }
                    if(val==1){
                  	  flag2=1;
                    }
                    if(val==2){
                  	  flag3=1;
                    }
                	alert("对不起：至少要选一项");
                	return false
                }
                //调用函数
                for(var i=0; i<message_xxaq.length;i++){
                	if(flag1){
                		if(message_xxaq[i].RECTIFY_STATE=='未处理'){
                			arr[arr.length]=message_xxaq[i];
                			continue;
                		}
                		
                	}
                	if(flag2){
                		if(message_xxaq[i].RECTIFY_STATE=='已关停'){
                			arr[arr.length]=message_xxaq[i];
                			continue;
                		}
                		
                	}
                	if(flag3){
                		if(message_xxaq[i].RECTIFY_STATE=='已下发'){
                			arr[arr.length]=message_xxaq[i];
                			continue;
                		}
                		
                	}
                }
                
                comprehensive_Rank(arr,'xingxianquan');
             });
        });
    var s2 = $("input[name='check2']");
    s2.each(function(i) {
            $(this).click(function(){
            	var arr=[];
                if(this.checked==true){
                      var val = this.value;
                      if(val==0){
                    	  flag4=1;
                      }
                      if(val==1){
                    	  flag5=1;
                      }
                      if(val==2){
                    	  flag6=1;
                      }
                }else{
                	var val = this.value;
                    if(val==0){
                  	  flag4=0;
                    }
                    if(val==1){
                  	  flag5=0;
                    }
                    if(val==2){
                  	  flag6=0;
                    }
                }
                if(flag4==0&&flag5==0&&flag6==0){
                	var val = this.value;
                	if(val==0){
                  	  flag4=1;
                    }
                    if(val==1){
                  	  flag5=1;
                    }
                    if(val==2){
                  	  flag6=1;
                    }
                    alert(flag4+"--"+flag5+"--"+flag6);
                	alert("对不起：至少要选一项");
                	return false
                }
                //调用函数
                for(var i=0; i<message_zzfd.length;i++){
                	if(flag4){
                		if(message_zzfd[i].RECTIFY_STATE=='未处理'){
                			arr[arr.length]=message_zzfd[i];
                			continue;
                		}
                		
                	}
                	if(flag5){
                		if(message_zzfd[i].RECTIFY_STATE=='已关停'){
                			arr[arr.length]=message_zzfd[i];
                			continue;
                		}
                		
                	}
                	if(flag6){
                		if(message_zzfd[i].RECTIFY_STATE=='已下发'){
                			arr[arr.length]=message_zzfd[i];
                			continue;
                		}
                		
                	}
                }
                
                comprehensive_Rank(arr,'wangluoanquan');
             });
        });
    var s3 = $("input[name='check3']");
    s3.each(function(i) {
            $(this).click(function(){
//            	var SelectFalse = true; //用于判断是否被选择条件
            	var arr=[];
                if(this.checked==true){
                      var val = this.value;
                      if(val==0){
                    	  flag7=1;
                      }
                      if(val==1){
                    	  flag8=1;
                      }
                      if(val==2){
                    	  flag9=1;
                      }
                }else{
                	var val = this.value;
                    if(val==0){
                  	  flag7=0;
                    }
                    if(val==1){
                  	  flag8=0;
                    }
                    if(val==2){
                  	  flag9=0;
                    }
                }
                if(flag7==0&&flag8==0&&flag9==0){
                	var val = this.value;
                	if(val==0){
                  	  flag7=1;
                    }
                    if(val==1){
                  	  flag8=1;
                    }
                    if(val==2){
                  	  flag9=1;
                    }
                	alert("对不起：至少要选一项");
                	return false
                }
                //调用函数
                for(var i=0; i<message_bkxx.length;i++){
                	if(flag7){
                		if(message_bkxx[i].RECTIFY_STATE=='未处理'){
                			arr[arr.length]=message_bkxx[i];
                			continue;
                		}
                		
                	}
                	if(flag8){
                		if(message_bkxx[i].RECTIFY_STATE=='已关停'){
                			arr[arr.length]=message_bkxx[i];
                			continue;
                		}
                		
                	}
                	if(flag9){
                		if(message_bkxx[i].RECTIFY_STATE=='已下发'){
                			arr[arr.length]=message_bkxx[i];
                			continue;
                		}
                		
                	}
                }
                
                comprehensive_Rank(arr,'weibeian');
             });
        });
}

//地图下面的点击事件切换
$(".addorless_city").click(function(){
	if(num==0){
		$("#map_city").css("display","none");
		$("#curve_city").css("display","block");
		line('curve_city',arr,'珠海市IDC安全态势');
		num=num+1;
		$(this).html("<");
	}else{
		$("#map_city").css("display","block");
		$("#curve_city").css("display","none");
		Map_city('map_city',rawData_city,"珠海市",geoCoordMap,'35%');
		num=num-1;
		$(this).html(">");
	}
});

